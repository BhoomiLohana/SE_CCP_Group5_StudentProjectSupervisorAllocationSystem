from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from core.models import Student, Supervisor, Project, Proposal, Config
User=get_user_model()
class Command(BaseCommand):
    help='Create demo users, profiles and sample proposals.'
    def handle(self,*args,**options):
        admin,_=User.objects.get_or_create(username='admin',defaults={'email':'admin@example.com','role':'admin','full_name':'System Administrator','is_staff':True,'is_superuser':True})
        admin.email='admin@example.com'; admin.role='admin'; admin.is_staff=True; admin.is_superuser=True; admin.set_password('admin1234'); admin.save()
        students=[('bhoomi','Bhoomi','TCT-24005'),('heer','Heer','TCT-24026'),('habiba','Habibah','TCT-029')]
        student_profiles=[]
        for username,name,roll in students:
            u,_=User.objects.get_or_create(username=username,defaults={'email':username+'@example.com','role':'student','full_name':name}); u.email=username+'@example.com'; u.full_name=name; u.role='student'; u.set_password('pass1234'); u.save()
            s,_=Student.objects.get_or_create(user=u,defaults={'roll_number':roll,'department':'Computer Science','semester':5}); student_profiles.append(s)
        for username,name,capacity,expertise in [('ayesha','Ayesha',2,'Web Development, Databases'),('imran','Imran',1,'AI, Machine Learning'),('sana','Sana',3,'Software Engineering, Networks')]:
            u,_=User.objects.get_or_create(username=username,defaults={'email':username+'@example.com','role':'supervisor','full_name':name}); u.email=username+'@example.com'; u.full_name=name; u.role='supervisor'; u.set_password('pass1234'); u.save()
            Supervisor.objects.update_or_create(user=u,defaults={'department':'Computer Science','expertise':expertise,'max_capacity':capacity})
        p1,_=Project.objects.get_or_create(title='Campus Event Management System',defaults={'description':'A web platform to manage university events.','objectives':'Centralize event registration and scheduling.','technologies':'Django, Bootstrap, SQLite'})
        Proposal.objects.get_or_create(project=p1,student=student_profiles[0],defaults={'status':'pending'})
        p2,_=Project.objects.get_or_create(title='Student Attendance Analytics',defaults={'description':'Analyze student attendance trends.','objectives':'Visualize attendance and identify patterns.','technologies':'Python, Django, Pandas'})
        Proposal.objects.get_or_create(project=p2,student=student_profiles[1],defaults={'status':'accepted','review_comments':'Promising idea. Please proceed with a clear evaluation plan.'})
        Config.current()
        self.stdout.write(self.style.SUCCESS('Demo data ready. Admin: admin/admin1234. Other users: pass1234.'))
