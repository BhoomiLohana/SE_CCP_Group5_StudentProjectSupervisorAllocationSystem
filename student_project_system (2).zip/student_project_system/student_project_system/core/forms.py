from django import forms
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from .models import Student, Project, Progress, Supervisor
User = get_user_model()

class LoginForm(forms.Form):
    username = forms.CharField(label='Email or username', max_length=254)
    password = forms.CharField(widget=forms.PasswordInput)

class StudentProfileForm(forms.ModelForm):
    full_name = forms.CharField(max_length=150)
    email = forms.EmailField()

    class Meta:
        model = Student
        fields = ['department', 'semester', 'roll_number']
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        self.fields['full_name'].initial = self.user.full_name or self.user.username
        self.fields['email'].initial = self.user.email
    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.exclude(pk=self.user.pk).filter(email__iexact=email).exists(): raise ValidationError('This email is already in use.')
        return email
    def save(self, commit=True):
        obj = super().save(commit=False)
        self.user.full_name = self.cleaned_data['full_name']
        self.user.email = self.cleaned_data['email']
        if commit:
            self.user.save(); obj.save()
        return obj

class ProposalForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description', 'objectives', 'technologies']
        widgets = {f: forms.Textarea(attrs={'rows': 3}) for f in ['description', 'objectives']}
    def clean(self):
        data = super().clean()
        for field in self.fields:
            if not (data.get(field) or '').strip(): self.add_error(field, 'This field is required.')
        return data

class ProgressForm(forms.ModelForm):
    class Meta:
        model = Progress
        fields = ['completed_tasks', 'pending_tasks', 'description']
        widgets = {f: forms.Textarea(attrs={'rows': 3}) for f in ['completed_tasks', 'pending_tasks', 'description']}

class SupervisorForm(forms.Form):
    full_name = forms.CharField(max_length=150)
    username = forms.CharField(max_length=150)
    email = forms.EmailField()
    department = forms.CharField(max_length=120)
    expertise = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}))
    max_capacity = forms.IntegerField(min_value=1)
    password = forms.CharField(required=False, widget=forms.PasswordInput, help_text='Required for a new supervisor; leave blank to keep existing password.')
    def __init__(self, *args, **kwargs):
        self.instance = kwargs.pop('instance', None)
        super().__init__(*args, **kwargs)
        if self.instance:
            u, s = self.instance.user, self.instance
            for k,v in {'full_name':u.full_name,'username':u.username,'email':u.email,'department':s.department,'expertise':s.expertise,'max_capacity':s.max_capacity}.items(): self.fields[k].initial=v
    def clean(self):
        data = super().clean()
        qs = User.objects.exclude(pk=self.instance.user_id) if self.instance else User.objects.all()
        if data.get('username') and qs.filter(username__iexact=data['username']).exists(): self.add_error('username','Username already exists.')
        if data.get('email') and qs.filter(email__iexact=data['email']).exists(): self.add_error('email','Email already exists.')
        if not self.instance and not data.get('password'): self.add_error('password','Password is required for a new supervisor.')
        if self.instance and data.get('max_capacity') is not None and data['max_capacity'] < self.instance.workload: self.add_error('max_capacity', f'Capacity cannot be below current workload ({self.instance.workload}).')
        return data
