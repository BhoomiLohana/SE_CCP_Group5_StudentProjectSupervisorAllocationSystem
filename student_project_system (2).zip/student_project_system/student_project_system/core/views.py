import csv
from functools import wraps
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction, IntegrityError
from django.db.models import Count
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from .decorators import role_required
from .forms import LoginForm, StudentProfileForm, ProposalForm, ProgressForm, SupervisorForm
from .models import User, Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config


def notify(user, message): Notification.objects.create(user=user, message=message)
def home(request): return redirect('dashboard') if request.user.is_authenticated else redirect('login')

def login_view(request):
    if request.user.is_authenticated: return redirect('dashboard')
    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(request, username=form.cleaned_data['username'], password=form.cleaned_data['password'])
        if user:
            login(request, user); return redirect('dashboard')
        messages.error(request, 'Invalid credentials or inactive account.')
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    if request.method == 'POST': logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    role = request.user.role
    if role == User.Roles.ADMIN:
        context = {'students_count': Student.objects.count(), 'supervisors_count': Supervisor.objects.count(),
            'total_proposals': Proposal.objects.count(), 'pending': Proposal.objects.filter(status='pending').count(),
            'approved': Proposal.objects.filter(status='accepted').count(), 'rejected': Proposal.objects.filter(status='rejected').count(),
            'allocations_count': Allocation.objects.filter(status='active').count(), 'config': Config.current(),
            'recent_proposals': Proposal.objects.select_related('project','student__user').order_by('-submitted_at')[:6]}
        return render(request, 'core/admin_dashboard.html', context)
    if role == User.Roles.STUDENT:
        student = get_object_or_404(Student, user=request.user)
        proposals = student.proposals.select_related('project','reviewed_by__user').order_by('-submitted_at')
        allocation = Allocation.objects.filter(project__proposals__student=student, status='active').select_related('supervisor__user','project').first()
        return render(request, 'core/student_dashboard.html', {'student':student,'proposals':proposals,'allocation':allocation,'progress':Progress.objects.filter(project__proposals__student=student).order_by('-submitted_at')[:5], 'feedback_items':Feedback.objects.filter(progress__project__proposals__student=student).select_related('progress','supervisor__user').order_by('-created_at')[:5]})
    if role == User.Roles.SUPERVISOR:
        supervisor = get_object_or_404(Supervisor, user=request.user)
        return render(request, 'core/supervisor_dashboard.html', {'supervisor':supervisor,'pending_proposals':Proposal.objects.filter(status='pending').select_related('project','student__user'),'allocations':supervisor.allocations.filter(status='active').select_related('project'),'progress_items':Progress.objects.filter(project__allocations__supervisor=supervisor, project__allocations__status='active').select_related('project','submitted_by').order_by('-submitted_at')[:8]})
    raise PermissionDenied

@role_required('student')
def student_profile(request):
    student = get_object_or_404(Student, user=request.user)
    form = StudentProfileForm(request.POST or None, instance=student, user=request.user)
    if request.method == 'POST' and form.is_valid(): form.save(); messages.success(request,'Profile updated successfully.'); return redirect('student_profile')
    return render(request,'core/student_profile.html',{'form':form,'heading':'My profile','subtitle':'Keep your student details up to date.'})

@role_required('student')
def submit_proposal(request):
    if not Config.current().submission_open:
        messages.error(request,'The project submission period is currently closed.'); return redirect('dashboard')
    form = ProposalForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        project = form.save()
        Proposal.objects.create(project=project, student=get_object_or_404(Student,user=request.user))
        notify(request.user, f'Your proposal “{project.title}” was submitted successfully.')
        for supervisor_user in User.objects.filter(role=User.Roles.SUPERVISOR, is_active=True): notify(supervisor_user, f'New project proposal submitted: {project.title}.')
        messages.success(request,'Proposal submitted successfully.'); return redirect('dashboard')
    return render(request,'core/proposal_form.html',{'form':form,'heading':'Submit project proposal','subtitle':'Complete all fields to send your project for review.'})

@role_required('supervisor')
def review_proposal(request, pk):
    proposal = get_object_or_404(Proposal.objects.select_related('project','student__user'),pk=pk)
    if request.method == 'POST':
        action = request.POST.get('action'); comment = request.POST.get('comment','').strip()
        if action not in ('accept','reject'):
            messages.error(request,'Choose accept or reject.')
        elif action == 'reject' and not comment:
            messages.error(request,'A comment is compulsory when rejecting a proposal.')
        elif proposal.status != Proposal.Status.PENDING:
            messages.error(request,'This proposal has already been reviewed.')
        else:
            supervisor = get_object_or_404(Supervisor,user=request.user)
            proposal.status = Proposal.Status.ACCEPTED if action == 'accept' else Proposal.Status.REJECTED
            proposal.reviewed_by = supervisor; proposal.review_comments = comment
            proposal.save(); proposal.project.status = Project.Status.APPROVED if action == 'accept' else Project.Status.REJECTED; proposal.project.save()
            notify(proposal.student.user, f'Your proposal “{proposal.project.title}” was {proposal.status}. {comment}')
            messages.success(request,'Proposal review saved.'); return redirect('dashboard')
    return render(request,'core/review_proposal.html',{'proposal':proposal})

@role_required('supervisor')
def progress_detail(request, pk):
    supervisor = get_object_or_404(Supervisor,user=request.user)
    progress = get_object_or_404(Progress.objects.select_related('project','submitted_by'),pk=pk,project__allocations__supervisor=supervisor,project__allocations__status='active')
    if request.method == 'POST':
        comments = request.POST.get('comments','').strip()
        if not comments: messages.error(request,'Feedback comments are required.')
        else:
            Feedback.objects.create(progress=progress,supervisor=supervisor,comments=comments)
            notify(progress.submitted_by, f'Your supervisor provided feedback on {progress.project.title}.')
            messages.success(request,'Feedback submitted.'); return redirect('progress_detail',pk=pk)
    return render(request,'core/progress_detail.html',{'progress':progress})

@role_required('student')
def submit_progress(request):
    student = get_object_or_404(Student,user=request.user)
    allocation = Allocation.objects.filter(project__proposals__student=student,status='active').select_related('project').first()
    if not allocation:
        messages.error(request,'You can submit progress only after a supervisor has been allocated.'); return redirect('dashboard')
    form = ProgressForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        progress = form.save(commit=False); progress.project=allocation.project; progress.submitted_by=request.user; progress.save()
        notify(allocation.supervisor.user, f'New progress update submitted for {allocation.project.title}.')
        messages.success(request,'Progress update submitted.'); return redirect('dashboard')
    return render(request,'core/progress_form.html',{'form':form,'project':allocation.project,'heading':'Submit progress update','subtitle':'Share completed work and what remains to be done.'})

@login_required
def notifications(request):
    items = request.user.notifications.all()
    if request.method == 'POST':
        items.filter(is_read=False).update(is_read=True); messages.success(request,'All notifications marked as read.'); return redirect('notifications')
    return render(request,'core/notifications.html',{'items':items})

@role_required('admin')
def toggle_submission(request):
    if request.method == 'POST':
        cfg=Config.current(); cfg.submission_open=not cfg.submission_open; cfg.save()
        messages.success(request, 'Submission period opened.' if cfg.submission_open else 'Submission period closed.')
    return redirect('dashboard')

@role_required('admin')
def supervisor_list(request): return render(request,'core/supervisor_list.html',{'supervisors':Supervisor.objects.select_related('user').all()})

@role_required('admin')
def supervisor_create(request):
    form=SupervisorForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; user=User.objects.create_user(username=d['username'],email=d['email'],password=d['password'],role='supervisor',full_name=d['full_name'])
        Supervisor.objects.create(user=user,department=d['department'],expertise=d['expertise'],max_capacity=d['max_capacity'])
        messages.success(request,'Supervisor created.'); return redirect('supervisor_list')
    return render(request,'core/supervisor_form.html',{'form':form,'heading':'Add supervisor','subtitle':'Enter supervisor account details, expertise and maximum workload.'})

@role_required('admin')
def supervisor_edit(request, pk):
    supervisor=get_object_or_404(Supervisor.objects.select_related('user'),pk=pk)
    form=SupervisorForm(request.POST or None,instance=supervisor)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; u=supervisor.user; u.full_name=d['full_name']; u.username=d['username']; u.email=d['email'];
        if d.get('password'): u.set_password(d['password'])
        u.save(); supervisor.department=d['department']; supervisor.expertise=d['expertise']; supervisor.max_capacity=d['max_capacity']; supervisor.save()
        messages.success(request,'Supervisor updated.'); return redirect('supervisor_list')
    return render(request,'core/supervisor_form.html',{'form':form,'heading':'Edit supervisor','subtitle':'Update profile details and capacity.'})

@role_required('admin')
def allocation_page(request):
    proposals=Proposal.objects.filter(status='accepted').exclude(project__allocations__status='active').select_related('project','student__user')
    if request.method=='POST':
        proposal=get_object_or_404(Proposal,pk=request.POST.get('proposal_id'),status='accepted')
        supervisor=get_object_or_404(Supervisor,pk=request.POST.get('supervisor_id'))
        try:
            with transaction.atomic():
                locked=Supervisor.objects.select_for_update().get(pk=supervisor.pk)
                if locked.allocations.filter(status='active').count() >= locked.max_capacity: raise ValueError('This supervisor has reached maximum capacity.')
                if Allocation.objects.filter(project=proposal.project,status='active').exists(): raise ValueError('This project already has an active allocation.')
                Allocation.objects.create(project=proposal.project,supervisor=locked,allocated_by=request.user)
                proposal.project.status=Project.Status.IN_PROGRESS; proposal.project.save()
                notify(proposal.student.user,f'Supervisor {locked.user.full_name} has been assigned to {proposal.project.title}.')
                notify(locked.user,f'You have been assigned project {proposal.project.title}.')
            messages.success(request,'Supervisor allocated successfully.')
            return redirect('allocation_page')
        except (ValueError, IntegrityError) as exc: messages.error(request,str(exc) or 'Allocation could not be completed.')
    return render(request,'core/allocations.html',{'proposals':proposals,'supervisors':Supervisor.objects.select_related('user').all(),'allocations':Allocation.objects.filter(status='active').select_related('project','supervisor__user')})

@role_required('admin')
def allocation_report(request):
    allocations=Allocation.objects.filter(status='active').select_related('project','supervisor__user','allocated_by').order_by('supervisor__user__full_name')
    if request.GET.get('format')=='csv':
        response=HttpResponse(content_type='text/csv'); response['Content-Disposition']='attachment; filename="allocation-report.csv"'
        writer=csv.writer(response); writer.writerow(['Project','Student','Supervisor','Department','Allocated At','Status'])
        for a in allocations:
            proposal=a.project.proposals.select_related('student__user').first()
            writer.writerow([a.project.title, proposal.student.user.full_name if proposal else '', a.supervisor.user.full_name, a.supervisor.department, a.allocated_at.strftime('%Y-%m-%d %H:%M'), a.status])
        return response
    return render(request,'core/report.html',{'allocations':allocations})
