from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (('System role', {'fields': ('role','full_name')}),)
    list_display = ('username','email','full_name','role','is_active')
    list_filter = ('role','is_active')
admin.site.register([Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config])
