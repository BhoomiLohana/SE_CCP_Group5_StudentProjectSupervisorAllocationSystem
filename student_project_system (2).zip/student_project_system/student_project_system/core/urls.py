from django.urls import path
from . import views
urlpatterns = [
 path('dashboard/',views.dashboard,name='dashboard'), path('student/profile/',views.student_profile,name='student_profile'),
 path('student/proposal/new/',views.submit_proposal,name='submit_proposal'), path('student/progress/new/',views.submit_progress,name='submit_progress'),
 path('supervisor/proposal/<int:pk>/review/',views.review_proposal,name='review_proposal'), path('supervisor/progress/<int:pk>/',views.progress_detail,name='progress_detail'),
 path('notifications/',views.notifications,name='notifications'), path('admin/submission-period/',views.toggle_submission,name='toggle_submission'),
 path('admin/supervisors/',views.supervisor_list,name='supervisor_list'), path('admin/supervisors/add/',views.supervisor_create,name='supervisor_create'),
 path('admin/supervisors/<int:pk>/edit/',views.supervisor_edit,name='supervisor_edit'), path('admin/allocations/',views.allocation_page,name='allocation_page'), path('admin/report/',views.allocation_report,name='allocation_report'),
]
