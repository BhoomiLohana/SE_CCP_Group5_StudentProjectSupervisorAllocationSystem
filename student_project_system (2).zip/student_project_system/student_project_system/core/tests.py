from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from core.models import Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Config
User=get_user_model()
class SystemTests(TestCase):
 def setUp(self):
  self.admin=User.objects.create_user('admin','admin@test.com','secret123',role='admin',full_name='Admin')
  self.su=User.objects.create_user('student','student@test.com','secret123',role='student',full_name='Student')
  self.student=Student.objects.create(user=self.su,department='CS',semester=5,roll_number='R1')
  self.vu=User.objects.create_user('supervisor','sup@test.com','secret123',role='supervisor',full_name='Supervisor')
  self.sup=Supervisor.objects.create(user=self.vu,department='CS',expertise='AI',max_capacity=1)
  self.project=Project.objects.create(title='Project A',description='Description',objectives='Objectives',technologies='Python')
  self.proposal=Proposal.objects.create(project=self.project,student=self.student)
  self.client=Client()
 def login(self,user='student',password='secret123'): self.client.login(username=user,password=password)
 def test_login_username_and_email(self):
  self.assertTrue(self.client.login(username='student',password='secret123')); self.client.logout(); self.assertTrue(self.client.login(username='student@test.com',password='secret123'))
 def test_inactive_login_denied(self):
  self.su.is_active=False; self.su.save(); self.assertFalse(self.client.login(username='student',password='secret123'))
 def test_role_restrictions(self):
  self.login(); self.assertEqual(self.client.get(reverse('allocation_page')).status_code,403)
 def test_anonymous_redirect(self): self.assertEqual(self.client.get(reverse('dashboard')).status_code,302)
 def test_proposal_required_validation(self):
  self.login(); r=self.client.post(reverse('submit_proposal'),{'title':'','description':'','objectives':'','technologies':''}); self.assertEqual(r.status_code,200); self.assertEqual(Proposal.objects.count(),1)
 def test_closed_submission_period(self):
  cfg=Config.current(); cfg.submission_open=False; cfg.save(); self.login(); self.client.post(reverse('submit_proposal'),{'title':'X','description':'D','objectives':'O','technologies':'T'}); self.assertEqual(Proposal.objects.count(),1)
 def test_reject_requires_comment(self):
  self.login('supervisor'); self.client.post(reverse('review_proposal',args=[self.proposal.pk]),{'action':'reject','comment':''}); self.proposal.refresh_from_db(); self.assertEqual(self.proposal.status,'pending')
 def test_capacity_check(self):
  self.proposal.status='accepted'; self.proposal.save()
  other=Project.objects.create(title='Other',description='D',objectives='O',technologies='T'); Allocation.objects.create(project=other,supervisor=self.sup,allocated_by=self.admin)
  self.login('admin'); self.client.post(reverse('allocation_page'),{'proposal_id':self.proposal.pk,'supervisor_id':self.sup.pk}); self.assertFalse(Allocation.objects.filter(project=self.project,status='active').exists())
 def test_duplicate_allocation(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
  from django.db import transaction
  with self.assertRaises(Exception):
   with transaction.atomic(): Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
 def test_progress_and_feedback(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
  self.login(); self.client.post(reverse('submit_progress'),{'completed_tasks':'Done','pending_tasks':'Next','description':'Update'}); self.assertEqual(Progress.objects.count(),1)
  progress=Progress.objects.first(); self.login('supervisor'); self.client.post(reverse('progress_detail',args=[progress.pk]),{'comments':'Good work'}); self.assertEqual(Feedback.objects.count(),1)
 def test_supervisor_add_and_edit(self):
  self.login('admin'); data={'full_name':'New','username':'new','email':'new@test.com','department':'CS','expertise':'Cloud','max_capacity':2,'password':'secret123'}
  self.client.post(reverse('supervisor_create'),data); new=Supervisor.objects.get(user__username='new'); data.update({'full_name':'New Name','max_capacity':3,'password':''})
  self.client.post(reverse('supervisor_edit',args=[new.pk]),data); new.refresh_from_db(); self.assertEqual(new.max_capacity,3); self.assertEqual(new.user.full_name,'New Name')
 def test_capacity_cannot_be_lowered_below_workload(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin); self.login('admin')
  data={'full_name':'Supervisor','username':'supervisor','email':'sup@test.com','department':'CS','expertise':'AI','max_capacity':0}
  r=self.client.post(reverse('supervisor_edit',args=[self.sup.pk]),data); self.assertEqual(r.status_code,200); self.sup.refresh_from_db(); self.assertEqual(self.sup.max_capacity,1)
 def test_csv_export(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin); self.login('admin')
  r=self.client.get(reverse('allocation_report')+'?format=csv'); self.assertEqual(r.status_code,200); self.assertIn(b'Project A',r.content)
