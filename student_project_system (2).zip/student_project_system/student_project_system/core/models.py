from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import Q
from django.utils import timezone

class User(AbstractUser):
    class Roles(models.TextChoices):
        ADMIN = 'admin', 'Administrator'
        STUDENT = 'student', 'Student'
        SUPERVISOR = 'supervisor', 'Supervisor'
    role = models.CharField(max_length=20, choices=Roles.choices, default=Roles.STUDENT)
    full_name = models.CharField(max_length=150, blank=True)
    email = models.EmailField(unique=True)
    def save(self, *args, **kwargs):
        if self.full_name:
            self.first_name = self.full_name
        elif self.first_name:
            self.full_name = self.first_name
        super().save(*args, **kwargs)
    def __str__(self):
        return self.full_name or self.username

class Student(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='student_profile')
    roll_number = models.CharField(max_length=40, unique=True, blank=True)
    department = models.CharField(max_length=120)
    semester = models.PositiveSmallIntegerField()
    def __str__(self): return f'{self.user} ({self.roll_number})'

class Supervisor(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='supervisor_profile')
    department = models.CharField(max_length=120)
    expertise = models.TextField()
    max_capacity = models.PositiveSmallIntegerField(default=1)
    @property
    def workload(self):
        return self.allocations.filter(status=Allocation.Status.ACTIVE).count()
    @property
    def available_capacity(self): return max(0, self.max_capacity - self.workload)
    def __str__(self): return self.user.full_name or self.user.username

class Project(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = 'submitted', 'Submitted'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'
        IN_PROGRESS = 'in_progress', 'In progress'
        COMPLETED = 'completed', 'Completed'
    title = models.CharField(max_length=200)
    description = models.TextField()
    objectives = models.TextField()
    technologies = models.CharField(max_length=300)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)
    created_at = models.DateTimeField(default=timezone.now)
    def __str__(self): return self.title

class Proposal(models.Model):
    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending'
        ACCEPTED = 'accepted', 'Accepted'
        REJECTED = 'rejected', 'Rejected'
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='proposals')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='proposals')
    reviewed_by = models.ForeignKey(Supervisor, null=True, blank=True, on_delete=models.SET_NULL, related_name='reviewed_proposals')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    submitted_at = models.DateTimeField(default=timezone.now)
    review_comments = models.TextField(blank=True)
    def __str__(self): return self.project.title

class Allocation(models.Model):
    class Status(models.TextChoices):
        ACTIVE = 'active', 'Active'
        INACTIVE = 'inactive', 'Inactive'
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='allocations')
    supervisor = models.ForeignKey(Supervisor, on_delete=models.PROTECT, related_name='allocations')
    allocated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='allocations_made')
    allocated_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.ACTIVE)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['project'], condition=Q(status='active'), name='one_active_allocation_per_project')]

class Progress(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='progress_updates')
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='progress_updates')
    completed_tasks = models.TextField()
    pending_tasks = models.TextField()
    description = models.TextField()
    submitted_at = models.DateTimeField(default=timezone.now)

class Feedback(models.Model):
    progress = models.ForeignKey(Progress, on_delete=models.CASCADE, related_name='feedback_entries')
    supervisor = models.ForeignKey(Supervisor, on_delete=models.CASCADE, related_name='feedback_entries')
    comments = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    message = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    class Meta: ordering = ['-created_at']

class Config(models.Model):
    submission_open = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    @classmethod
    def current(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj
