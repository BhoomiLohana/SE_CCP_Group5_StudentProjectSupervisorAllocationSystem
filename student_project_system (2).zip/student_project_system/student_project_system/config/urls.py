
from django.contrib import admin
from django.urls import path, include
from core import views

urlpatterns = [
    path('', views.home, name='home'),
    path('accounts/login/', views.login_view, name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),

    # Custom application URLs must come before Django Admin
    path('', include('core.urls')),

    # Django Admin should come after custom application URLs
    path('admin/', admin.site.urls),
]
