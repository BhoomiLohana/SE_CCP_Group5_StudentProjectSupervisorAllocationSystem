# Student Project and Supervisor Allocation System

A Django 5 server-rendered prototype based on the supplied Project Proposal and Feasibility Report, SRS, and System Analysis and Design documents. It implements the three-tier browser/Django/database architecture, the Administrator/Student/Supervisor roles, proposal review, manual supervisor allocation with capacity enforcement, progress and feedback, notifications, and allocation reporting.

## Requirements

- Python 3.10 or newer
- pip
- A modern browser (Chrome, Firefox, or Edge)

SQLite is used automatically. PostgreSQL is selected only when **all five** environment variables `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT` are set. For PostgreSQL, install a compatible driver separately (`psycopg2-binary`); it is not needed for the default SQLite setup.

## Windows Command Prompt (cmd) — fresh setup

Open Command Prompt in the extracted `student_project_system` folder:

```bat
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py seed
python manage.py runserver
```

Open http://127.0.0.1:8000/ in your browser.

## Demo accounts

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `admin1234` |
| Student | `bhoomi` | `pass1234` |
| Student | `heer` | `pass1234` |
| Student | `habiba` | `pass1234` |
| Supervisor | `ayesha` | `pass1234` |
| Supervisor | `imran` | `pass1234` |
| Supervisor | `sana` | `pass1234` |

You can also sign in with each account's email address (for example `habiba@example.com`) instead of its username.

## Run automated tests

```bat
python manage.py test
```

The Django test client tests cover username/email login, inactive-account login denial, anonymous redirects, role restrictions, required proposal fields, closed submission period, rejection comments, supervisor capacity, duplicate active allocations, progress and feedback, supervisor creation/editing, capacity validation on edit, and CSV export.

## Main routes

- `/accounts/login/` — login
- `/dashboard/` — role-specific dashboard
- `/student/profile/` — student profile
- `/student/proposal/new/` — submit proposal
- `/student/progress/new/` — submit progress after allocation
- `/supervisor/proposal/<id>/review/` — review a proposal
- `/supervisor/progress/<id>/` — review progress and send feedback
- `/notifications/` — personal notifications and mark-all-read
- `/admin/` — Django account administration (staff/superuser)
- `/admin/supervisors/` — supervisor profile/capacity management
- `/admin/allocations/` — allocate accepted proposals
- `/admin/report/` — on-screen allocation report, CSV and print

## Notes

- All forms use Django CSRF protection and server-side validation.
- Passwords are stored using Django's password hashers.
- Inactive users are rejected by Django authentication.
- Role guards return HTTP 403 for authenticated users who attempt another role's routes; anonymous users are redirected to login.
- Allocation is wrapped in a database transaction, checks current supervisor workload, and the database has a conditional unique constraint allowing only one active allocation per project.
- `python manage.py seed` is idempotent for the supplied demo accounts and sample proposals. The sample accepted proposal is ready for administrator allocation.
- The prototype deliberately keeps the documents' stated manual allocation approach; it does not add AI allocation, payment, conferencing, mobile apps, or plagiarism detection.
