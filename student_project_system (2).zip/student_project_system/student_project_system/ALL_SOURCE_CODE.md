# Complete source listing

Each section below contains the complete contents of one project file.

## `.gitignore`

```text
.venv/
__pycache__/
*.py[cod]
db.sqlite3
.env
staticfiles/

```

## `README.md`

```markdown
# Student Project and Supervisor Allocation System

A Django 5 server-rendered prototype based on the supplied Project Proposal and Feasibility Report, SRS, and System Analysis and Design documents. It implements the three-tier browser/Django/database architecture, the Administrator/Student/Supervisor roles, proposal review, manual supervisor allocation with capacity enforcement, progress and feedback, notifications, and allocation reporting.

## Requirements

- Python 3.10 or newer
- pip
- A modern browser (Chrome, Firefox, or Edge)

SQLite is used automatically. PostgreSQL is selected only when **all five** environment variables `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT` are set. For PostgreSQL, install a compatible driver separately (`psycopg2-binary`); it is not needed for the default SQLite setup.

## Windows Command Prompt (cmd) — fresh setup

Open Command Prompt in the extracted `student_project_system` folder:

```bat
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py seed
python manage.py runserver
```

Open http://127.0.0.1:8000/ in your browser.

## Demo accounts

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `admin1234` |
| Student | `bhoomi` | `pass1234` |
| Student | `heer` | `pass1234` |
| Student | `habiba` | `pass1234` |
| Supervisor | `ayesha` | `pass1234` |
| Supervisor | `imran` | `pass1234` |
| Supervisor | `sana` | `pass1234` |

You can also sign in with each account's email address (for example `habiba@example.com`) instead of its username.

## Run automated tests

```bat
python manage.py test
```

The Django test client tests cover username/email login, inactive-account login denial, anonymous redirects, role restrictions, required proposal fields, closed submission period, rejection comments, supervisor capacity, duplicate active allocations, progress and feedback, supervisor creation/editing, capacity validation on edit, and CSV export.

## Main routes

- `/accounts/login/` — login
- `/dashboard/` — role-specific dashboard
- `/student/profile/` — student profile
- `/student/proposal/new/` — submit proposal
- `/student/progress/new/` — submit progress after allocation
- `/supervisor/proposal/<id>/review/` — review a proposal
- `/supervisor/progress/<id>/` — review progress and send feedback
- `/notifications/` — personal notifications and mark-all-read
- `/admin/` — Django account administration (staff/superuser)
- `/admin/supervisors/` — supervisor profile/capacity management
- `/admin/allocations/` — allocate accepted proposals
- `/admin/report/` — on-screen allocation report, CSV and print

## Notes

- All forms use Django CSRF protection and server-side validation.
- Passwords are stored using Django's password hashers.
- Inactive users are rejected by Django authentication.
- Role guards return HTTP 403 for authenticated users who attempt another role's routes; anonymous users are redirected to login.
- Allocation is wrapped in a database transaction, checks current supervisor workload, and the database has a conditional unique constraint allowing only one active allocation per project.
- `python manage.py seed` is idempotent for the supplied demo accounts and sample proposals. The sample accepted proposal is ready for administrator allocation.
- The prototype deliberately keeps the documents' stated manual allocation approach; it does not add AI allocation, payment, conferencing, mobile apps, or plagiarism detection.

```

## `config/__init__.py`

```python

```

## `config/asgi.py`

```python
import os
from django.core.asgi import get_asgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
application = get_asgi_application()

```

## `config/settings.py`

```python
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'django-insecure-student-project-prototype-key-change-in-production')
DEBUG = os.environ.get('DJANGO_DEBUG', '1') == '1'
ALLOWED_HOSTS = [h for h in os.environ.get('DJANGO_ALLOWED_HOSTS', '127.0.0.1,localhost').split(',') if h]

INSTALLED_APPS = [
    'django.contrib.admin', 'django.contrib.auth', 'django.contrib.contenttypes',
    'django.contrib.sessions', 'django.contrib.messages', 'django.contrib.staticfiles',
    'core',
]
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
ROOT_URLCONF = 'config.urls'
TEMPLATES = [{
    'BACKEND': 'django.template.backends.django.DjangoTemplates',
    'DIRS': [BASE_DIR / 'templates'], 'APP_DIRS': True,
    'OPTIONS': {'context_processors': [
        'django.template.context_processors.debug', 'django.template.context_processors.request',
        'django.contrib.auth.context_processors.auth', 'django.contrib.messages.context_processors.messages',
        'core.context_processors.global_context',
    ]},
}]
WSGI_APPLICATION = 'config.wsgi.application'

pg_keys = ['DB_NAME', 'DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_PORT']
if all(os.environ.get(k) for k in pg_keys):
    DATABASES = {'default': {'ENGINE': 'django.db.backends.postgresql', 'NAME': os.environ['DB_NAME'],
        'USER': os.environ['DB_USER'], 'PASSWORD': os.environ['DB_PASSWORD'],
        'HOST': os.environ['DB_HOST'], 'PORT': os.environ['DB_PORT']}}
else:
    DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': BASE_DIR / 'db.sqlite3'}}

AUTH_USER_MODEL = 'core.User'
AUTHENTICATION_BACKENDS = ['core.backends.EmailOrUsernameBackend']
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Karachi'
USE_I18N = True
USE_TZ = True
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'dashboard'
LOGOUT_REDIRECT_URL = 'login'

```

## `config/urls.py`

```python
from django.contrib import admin
from django.urls import path, include
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('accounts/login/', views.login_view, name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),
    path('', include('core.urls')),
]

```

## `config/wsgi.py`

```python
import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
application = get_wsgi_application()

```

## `core/__init__.py`

```python

```

## `core/admin.py`

```python
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (('System role', {'fields': ('role','full_name')}),)
    list_display = ('username','email','full_name','role','is_active')
    list_filter = ('role','is_active')
admin.site.register([Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config])

```

## `core/apps.py`

```python
from django.apps import AppConfig
class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

```

## `core/backends.py`

```python
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

class EmailOrUsernameBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        User = get_user_model()
        identifier = username or kwargs.get(User.USERNAME_FIELD)
        if not identifier or password is None:
            return None
        try:
            user = User.objects.get(email__iexact=identifier) if '@' in identifier else User.objects.get(username__iexact=identifier)
        except User.DoesNotExist:
            User().set_password(password)
            return None
        if user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None

```

## `core/context_processors.py`

```python
def global_context(request):
    if request.user.is_authenticated:
        return {'unread_notifications': request.user.notifications.filter(is_read=False).count()}
    return {'unread_notifications': 0}

```

## `core/decorators.py`

```python
from functools import wraps
from django.core.exceptions import PermissionDenied
from django.contrib.auth.views import redirect_to_login

def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated: return redirect_to_login(request.get_full_path())
            if request.user.role not in roles: raise PermissionDenied
            return view(request, *args, **kwargs)
        return wrapped
    return decorator

```

## `core/forms.py`

```python
from django import forms
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from .models import Student, Project, Progress, Supervisor
User = get_user_model()

class LoginForm(forms.Form):
    username = forms.CharField(label='Email or username', max_length=254)
    password = forms.CharField(widget=forms.PasswordInput)

class StudentProfileForm(forms.ModelForm):
    full_name = forms.CharField(max_length=150)
    email = forms.EmailField()

    class Meta:
        model = Student
        fields = ['department', 'semester', 'roll_number']
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        self.fields['full_name'].initial = self.user.full_name or self.user.username
        self.fields['email'].initial = self.user.email
    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.exclude(pk=self.user.pk).filter(email__iexact=email).exists(): raise ValidationError('This email is already in use.')
        return email
    def save(self, commit=True):
        obj = super().save(commit=False)
        self.user.full_name = self.cleaned_data['full_name']
        self.user.email = self.cleaned_data['email']
        if commit:
            self.user.save(); obj.save()
        return obj

class ProposalForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description', 'objectives', 'technologies']
        widgets = {f: forms.Textarea(attrs={'rows': 3}) for f in ['description', 'objectives']}
    def clean(self):
        data = super().clean()
        for field in self.fields:
            if not (data.get(field) or '').strip(): self.add_error(field, 'This field is required.')
        return data

class ProgressForm(forms.ModelForm):
    class Meta:
        model = Progress
        fields = ['completed_tasks', 'pending_tasks', 'description']
        widgets = {f: forms.Textarea(attrs={'rows': 3}) for f in ['completed_tasks', 'pending_tasks', 'description']}

class SupervisorForm(forms.Form):
    full_name = forms.CharField(max_length=150)
    username = forms.CharField(max_length=150)
    email = forms.EmailField()
    department = forms.CharField(max_length=120)
    expertise = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}))
    max_capacity = forms.IntegerField(min_value=1)
    password = forms.CharField(required=False, widget=forms.PasswordInput, help_text='Required for a new supervisor; leave blank to keep existing password.')
    def __init__(self, *args, **kwargs):
        self.instance = kwargs.pop('instance', None)
        super().__init__(*args, **kwargs)
        if self.instance:
            u, s = self.instance.user, self.instance
            for k,v in {'full_name':u.full_name,'username':u.username,'email':u.email,'department':s.department,'expertise':s.expertise,'max_capacity':s.max_capacity}.items(): self.fields[k].initial=v
    def clean(self):
        data = super().clean()
        qs = User.objects.exclude(pk=self.instance.user_id) if self.instance else User.objects.all()
        if data.get('username') and qs.filter(username__iexact=data['username']).exists(): self.add_error('username','Username already exists.')
        if data.get('email') and qs.filter(email__iexact=data['email']).exists(): self.add_error('email','Email already exists.')
        if not self.instance and not data.get('password'): self.add_error('password','Password is required for a new supervisor.')
        if self.instance and data.get('max_capacity') is not None and data['max_capacity'] < self.instance.workload: self.add_error('max_capacity', f'Capacity cannot be below current workload ({self.instance.workload}).')
        return data

```

## `core/management/__init__.py`

```python

```

## `core/management/commands/__init__.py`

```python

```

## `core/management/commands/seed.py`

```python
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from core.models import Student, Supervisor, Project, Proposal, Config
User=get_user_model()
class Command(BaseCommand):
    help='Create demo users, profiles and sample proposals.'
    def handle(self,*args,**options):
        admin,_=User.objects.get_or_create(username='admin',defaults={'email':'admin@example.com','role':'admin','full_name':'System Administrator','is_staff':True,'is_superuser':True})
        admin.email='admin@example.com'; admin.role='admin'; admin.is_staff=True; admin.is_superuser=True; admin.set_password('admin1234'); admin.save()
        students=[('bhoomi','Bhoomi','TCT-24005'),('heer','Heer','TCT-24026'),('habiba','Habibah','TCT-029')]
        student_profiles=[]
        for username,name,roll in students:
            u,_=User.objects.get_or_create(username=username,defaults={'email':username+'@example.com','role':'student','full_name':name}); u.email=username+'@example.com'; u.full_name=name; u.role='student'; u.set_password('pass1234'); u.save()
            s,_=Student.objects.get_or_create(user=u,defaults={'roll_number':roll,'department':'Computer Science','semester':5}); student_profiles.append(s)
        for username,name,capacity,expertise in [('ayesha','Ayesha',2,'Web Development, Databases'),('imran','Imran',1,'AI, Machine Learning'),('sana','Sana',3,'Software Engineering, Networks')]:
            u,_=User.objects.get_or_create(username=username,defaults={'email':username+'@example.com','role':'supervisor','full_name':name}); u.email=username+'@example.com'; u.full_name=name; u.role='supervisor'; u.set_password('pass1234'); u.save()
            Supervisor.objects.update_or_create(user=u,defaults={'department':'Computer Science','expertise':expertise,'max_capacity':capacity})
        p1,_=Project.objects.get_or_create(title='Campus Event Management System',defaults={'description':'A web platform to manage university events.','objectives':'Centralize event registration and scheduling.','technologies':'Django, Bootstrap, SQLite'})
        Proposal.objects.get_or_create(project=p1,student=student_profiles[0],defaults={'status':'pending'})
        p2,_=Project.objects.get_or_create(title='Student Attendance Analytics',defaults={'description':'Analyze student attendance trends.','objectives':'Visualize attendance and identify patterns.','technologies':'Python, Django, Pandas'})
        Proposal.objects.get_or_create(project=p2,student=student_profiles[1],defaults={'status':'accepted','review_comments':'Promising idea. Please proceed with a clear evaluation plan.'})
        Config.current()
        self.stdout.write(self.style.SUCCESS('Demo data ready. Admin: admin/admin1234. Other users: pass1234.'))

```

## `core/migrations/0001_initial.py`

```python
import django.contrib.auth.models
import django.contrib.auth.validators
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [('auth', '0012_alter_user_first_name_max_length')]
    operations = [
        migrations.CreateModel(name='User', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('password', models.CharField(max_length=128, verbose_name='password')),
            ('last_login', models.DateTimeField(blank=True, null=True, verbose_name='last login')),
            ('is_superuser', models.BooleanField(default=False, help_text='Designates that this user has all permissions without explicitly assigning them.', verbose_name='superuser status')),
            ('username', models.CharField(error_messages={'unique': 'A user with that username already exists.'}, help_text='Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.', max_length=150, unique=True, validators=[django.contrib.auth.validators.UnicodeUsernameValidator()], verbose_name='username')),
            ('first_name', models.CharField(blank=True, max_length=150, verbose_name='first name')),
            ('last_name', models.CharField(blank=True, max_length=150, verbose_name='last name')),
            ('email', models.EmailField(max_length=254, unique=True)),
            ('is_staff', models.BooleanField(default=False, help_text='Designates whether the user can log into this admin site.', verbose_name='staff status')),
            ('is_active', models.BooleanField(default=True, help_text='Designates whether this user should be treated as active. Unselect this instead of deleting accounts.', verbose_name='active')),
            ('date_joined', models.DateTimeField(default=django.utils.timezone.now, verbose_name='date joined')),
            ('role', models.CharField(choices=[('admin', 'Administrator'), ('student', 'Student'), ('supervisor', 'Supervisor')], default='student', max_length=20)),
            ('full_name', models.CharField(blank=True, max_length=150)),
            ('groups', models.ManyToManyField(blank=True, help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.', related_name='user_set', related_query_name='user', to='auth.group', verbose_name='groups')),
            ('user_permissions', models.ManyToManyField(blank=True, help_text='Specific permissions for this user.', related_name='user_set', related_query_name='user', to='auth.permission', verbose_name='user permissions')),
        ], options={'verbose_name': 'user', 'verbose_name_plural': 'users', 'abstract': False}, managers=[('objects', django.contrib.auth.models.UserManager())]),
        migrations.CreateModel(name='Config', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('submission_open',models.BooleanField(default=True)),('updated_at',models.DateTimeField(auto_now=True))]),
        migrations.CreateModel(name='Project', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('title',models.CharField(max_length=200)),('description',models.TextField()),('objectives',models.TextField()),('technologies',models.CharField(max_length=300)),('status',models.CharField(choices=[('submitted','Submitted'),('approved','Approved'),('rejected','Rejected'),('in_progress','In progress'),('completed','Completed')],default='submitted',max_length=20)),('created_at',models.DateTimeField(default=django.utils.timezone.now))]),
        migrations.CreateModel(name='Student', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('roll_number',models.CharField(blank=True,max_length=40,unique=True)),('department',models.CharField(max_length=120)),('semester',models.PositiveSmallIntegerField()),('user',models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,related_name='student_profile',to=settings.AUTH_USER_MODEL))]),
        migrations.CreateModel(name='Supervisor', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('department',models.CharField(max_length=120)),('expertise',models.TextField()),('max_capacity',models.PositiveSmallIntegerField(default=1)),('user',models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,related_name='supervisor_profile',to=settings.AUTH_USER_MODEL))]),
        migrations.CreateModel(name='Proposal', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('status',models.CharField(choices=[('pending','Pending'),('accepted','Accepted'),('rejected','Rejected')],default='pending',max_length=20)),('submitted_at',models.DateTimeField(default=django.utils.timezone.now)),('review_comments',models.TextField(blank=True)),('project',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='proposals',to='core.project')),('reviewed_by',models.ForeignKey(blank=True,null=True,on_delete=django.db.models.deletion.SET_NULL,related_name='reviewed_proposals',to='core.supervisor')),('student',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='proposals',to='core.student'))]),
        migrations.CreateModel(name='Allocation', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('allocated_at',models.DateTimeField(default=django.utils.timezone.now)),('status',models.CharField(choices=[('active','Active'),('inactive','Inactive')],default='active',max_length=12)),('allocated_by',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='allocations_made',to=settings.AUTH_USER_MODEL)),('project',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='allocations',to='core.project')),('supervisor',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='allocations',to='core.supervisor'))]),
        migrations.CreateModel(name='Progress', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('completed_tasks',models.TextField()),('pending_tasks',models.TextField()),('description',models.TextField()),('submitted_at',models.DateTimeField(default=django.utils.timezone.now)),('project',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='progress_updates',to='core.project')),('submitted_by',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='progress_updates',to=settings.AUTH_USER_MODEL))]),
        migrations.CreateModel(name='Feedback', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('comments',models.TextField()),('created_at',models.DateTimeField(default=django.utils.timezone.now)),('progress',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='feedback_entries',to='core.progress')),('supervisor',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='feedback_entries',to='core.supervisor'))]),
        migrations.CreateModel(name='Notification', fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('message',models.CharField(max_length=255)),('is_read',models.BooleanField(default=False)),('created_at',models.DateTimeField(default=django.utils.timezone.now)),('user',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='notifications',to=settings.AUTH_USER_MODEL))], options={'ordering':['-created_at']}),
        migrations.AddConstraint(model_name='allocation',constraint=models.UniqueConstraint(condition=models.Q(('status','active')),fields=('project',),name='one_active_allocation_per_project')),
    ]

```

## `core/migrations/__init__.py`

```python

```

## `core/models.py`

```python
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import Q
from django.utils import timezone

class User(AbstractUser):
    class Roles(models.TextChoices):
        ADMIN = 'admin', 'Administrator'
        STUDENT = 'student', 'Student'
        SUPERVISOR = 'supervisor', 'Supervisor'
    role = models.CharField(max_length=20, choices=Roles.choices, default=Roles.STUDENT)
    full_name = models.CharField(max_length=150, blank=True)
    email = models.EmailField(unique=True)
    def save(self, *args, **kwargs):
        if self.full_name:
            self.first_name = self.full_name
        elif self.first_name:
            self.full_name = self.first_name
        super().save(*args, **kwargs)
    def __str__(self):
        return self.full_name or self.username

class Student(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='student_profile')
    roll_number = models.CharField(max_length=40, unique=True, blank=True)
    department = models.CharField(max_length=120)
    semester = models.PositiveSmallIntegerField()
    def __str__(self): return f'{self.user} ({self.roll_number})'

class Supervisor(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='supervisor_profile')
    department = models.CharField(max_length=120)
    expertise = models.TextField()
    max_capacity = models.PositiveSmallIntegerField(default=1)
    @property
    def workload(self):
        return self.allocations.filter(status=Allocation.Status.ACTIVE).count()
    @property
    def available_capacity(self): return max(0, self.max_capacity - self.workload)
    def __str__(self): return self.user.full_name or self.user.username

class Project(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = 'submitted', 'Submitted'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'
        IN_PROGRESS = 'in_progress', 'In progress'
        COMPLETED = 'completed', 'Completed'
    title = models.CharField(max_length=200)
    description = models.TextField()
    objectives = models.TextField()
    technologies = models.CharField(max_length=300)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)
    created_at = models.DateTimeField(default=timezone.now)
    def __str__(self): return self.title

class Proposal(models.Model):
    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending'
        ACCEPTED = 'accepted', 'Accepted'
        REJECTED = 'rejected', 'Rejected'
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='proposals')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='proposals')
    reviewed_by = models.ForeignKey(Supervisor, null=True, blank=True, on_delete=models.SET_NULL, related_name='reviewed_proposals')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    submitted_at = models.DateTimeField(default=timezone.now)
    review_comments = models.TextField(blank=True)
    def __str__(self): return self.project.title

class Allocation(models.Model):
    class Status(models.TextChoices):
        ACTIVE = 'active', 'Active'
        INACTIVE = 'inactive', 'Inactive'
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='allocations')
    supervisor = models.ForeignKey(Supervisor, on_delete=models.PROTECT, related_name='allocations')
    allocated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='allocations_made')
    allocated_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.ACTIVE)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['project'], condition=Q(status='active'), name='one_active_allocation_per_project')]

class Progress(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='progress_updates')
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='progress_updates')
    completed_tasks = models.TextField()
    pending_tasks = models.TextField()
    description = models.TextField()
    submitted_at = models.DateTimeField(default=timezone.now)

class Feedback(models.Model):
    progress = models.ForeignKey(Progress, on_delete=models.CASCADE, related_name='feedback_entries')
    supervisor = models.ForeignKey(Supervisor, on_delete=models.CASCADE, related_name='feedback_entries')
    comments = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    message = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    class Meta: ordering = ['-created_at']

class Config(models.Model):
    submission_open = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    @classmethod
    def current(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

```

## `core/tests.py`

```python
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from core.models import Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Config
User=get_user_model()
class SystemTests(TestCase):
 def setUp(self):
  self.admin=User.objects.create_user('admin','admin@test.com','secret123',role='admin',full_name='Admin')
  self.su=User.objects.create_user('student','student@test.com','secret123',role='student',full_name='Student')
  self.student=Student.objects.create(user=self.su,department='CS',semester=5,roll_number='R1')
  self.vu=User.objects.create_user('supervisor','sup@test.com','secret123',role='supervisor',full_name='Supervisor')
  self.sup=Supervisor.objects.create(user=self.vu,department='CS',expertise='AI',max_capacity=1)
  self.project=Project.objects.create(title='Project A',description='Description',objectives='Objectives',technologies='Python')
  self.proposal=Proposal.objects.create(project=self.project,student=self.student)
  self.client=Client()
 def login(self,user='student',password='secret123'): self.client.login(username=user,password=password)
 def test_login_username_and_email(self):
  self.assertTrue(self.client.login(username='student',password='secret123')); self.client.logout(); self.assertTrue(self.client.login(username='student@test.com',password='secret123'))
 def test_inactive_login_denied(self):
  self.su.is_active=False; self.su.save(); self.assertFalse(self.client.login(username='student',password='secret123'))
 def test_role_restrictions(self):
  self.login(); self.assertEqual(self.client.get(reverse('allocation_page')).status_code,403)
 def test_anonymous_redirect(self): self.assertEqual(self.client.get(reverse('dashboard')).status_code,302)
 def test_proposal_required_validation(self):
  self.login(); r=self.client.post(reverse('submit_proposal'),{'title':'','description':'','objectives':'','technologies':''}); self.assertEqual(r.status_code,200); self.assertEqual(Proposal.objects.count(),1)
 def test_closed_submission_period(self):
  cfg=Config.current(); cfg.submission_open=False; cfg.save(); self.login(); self.client.post(reverse('submit_proposal'),{'title':'X','description':'D','objectives':'O','technologies':'T'}); self.assertEqual(Proposal.objects.count(),1)
 def test_reject_requires_comment(self):
  self.login('supervisor'); self.client.post(reverse('review_proposal',args=[self.proposal.pk]),{'action':'reject','comment':''}); self.proposal.refresh_from_db(); self.assertEqual(self.proposal.status,'pending')
 def test_capacity_check(self):
  self.proposal.status='accepted'; self.proposal.save()
  other=Project.objects.create(title='Other',description='D',objectives='O',technologies='T'); Allocation.objects.create(project=other,supervisor=self.sup,allocated_by=self.admin)
  self.login('admin'); self.client.post(reverse('allocation_page'),{'proposal_id':self.proposal.pk,'supervisor_id':self.sup.pk}); self.assertFalse(Allocation.objects.filter(project=self.project,status='active').exists())
 def test_duplicate_allocation(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
  from django.db import transaction
  with self.assertRaises(Exception):
   with transaction.atomic(): Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
 def test_progress_and_feedback(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin)
  self.login(); self.client.post(reverse('submit_progress'),{'completed_tasks':'Done','pending_tasks':'Next','description':'Update'}); self.assertEqual(Progress.objects.count(),1)
  progress=Progress.objects.first(); self.login('supervisor'); self.client.post(reverse('progress_detail',args=[progress.pk]),{'comments':'Good work'}); self.assertEqual(Feedback.objects.count(),1)
 def test_supervisor_add_and_edit(self):
  self.login('admin'); data={'full_name':'New','username':'new','email':'new@test.com','department':'CS','expertise':'Cloud','max_capacity':2,'password':'secret123'}
  self.client.post(reverse('supervisor_create'),data); new=Supervisor.objects.get(user__username='new'); data.update({'full_name':'New Name','max_capacity':3,'password':''})
  self.client.post(reverse('supervisor_edit',args=[new.pk]),data); new.refresh_from_db(); self.assertEqual(new.max_capacity,3); self.assertEqual(new.user.full_name,'New Name')
 def test_capacity_cannot_be_lowered_below_workload(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin); self.login('admin')
  data={'full_name':'Supervisor','username':'supervisor','email':'sup@test.com','department':'CS','expertise':'AI','max_capacity':0}
  r=self.client.post(reverse('supervisor_edit',args=[self.sup.pk]),data); self.assertEqual(r.status_code,200); self.sup.refresh_from_db(); self.assertEqual(self.sup.max_capacity,1)
 def test_csv_export(self):
  Allocation.objects.create(project=self.project,supervisor=self.sup,allocated_by=self.admin); self.login('admin')
  r=self.client.get(reverse('allocation_report')+'?format=csv'); self.assertEqual(r.status_code,200); self.assertIn(b'Project A',r.content)

```

## `core/urls.py`

```python
from django.urls import path
from . import views
urlpatterns = [
 path('dashboard/',views.dashboard,name='dashboard'), path('student/profile/',views.student_profile,name='student_profile'),
 path('student/proposal/new/',views.submit_proposal,name='submit_proposal'), path('student/progress/new/',views.submit_progress,name='submit_progress'),
 path('supervisor/proposal/<int:pk>/review/',views.review_proposal,name='review_proposal'), path('supervisor/progress/<int:pk>/',views.progress_detail,name='progress_detail'),
 path('notifications/',views.notifications,name='notifications'), path('admin/submission-period/',views.toggle_submission,name='toggle_submission'),
 path('admin/supervisors/',views.supervisor_list,name='supervisor_list'), path('admin/supervisors/add/',views.supervisor_create,name='supervisor_create'),
 path('admin/supervisors/<int:pk>/edit/',views.supervisor_edit,name='supervisor_edit'), path('admin/allocations/',views.allocation_page,name='allocation_page'), path('admin/report/',views.allocation_report,name='allocation_report'),
]

```

## `core/views.py`

```python
import csv
from functools import wraps
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction, IntegrityError
from django.db.models import Count
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from .decorators import role_required
from .forms import LoginForm, StudentProfileForm, ProposalForm, ProgressForm, SupervisorForm
from .models import User, Student, Supervisor, Project, Proposal, Allocation, Progress, Feedback, Notification, Config


def notify(user, message): Notification.objects.create(user=user, message=message)
def home(request): return redirect('dashboard') if request.user.is_authenticated else redirect('login')

def login_view(request):
    if request.user.is_authenticated: return redirect('dashboard')
    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(request, username=form.cleaned_data['username'], password=form.cleaned_data['password'])
        if user:
            login(request, user); return redirect('dashboard')
        messages.error(request, 'Invalid credentials or inactive account.')
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    if request.method == 'POST': logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    role = request.user.role
    if role == User.Roles.ADMIN:
        context = {'students_count': Student.objects.count(), 'supervisors_count': Supervisor.objects.count(),
            'total_proposals': Proposal.objects.count(), 'pending': Proposal.objects.filter(status='pending').count(),
            'approved': Proposal.objects.filter(status='accepted').count(), 'rejected': Proposal.objects.filter(status='rejected').count(),
            'allocations_count': Allocation.objects.filter(status='active').count(), 'config': Config.current(),
            'recent_proposals': Proposal.objects.select_related('project','student__user').order_by('-submitted_at')[:6]}
        return render(request, 'core/admin_dashboard.html', context)
    if role == User.Roles.STUDENT:
        student = get_object_or_404(Student, user=request.user)
        proposals = student.proposals.select_related('project','reviewed_by__user').order_by('-submitted_at')
        allocation = Allocation.objects.filter(project__proposals__student=student, status='active').select_related('supervisor__user','project').first()
        return render(request, 'core/student_dashboard.html', {'student':student,'proposals':proposals,'allocation':allocation,'progress':Progress.objects.filter(project__proposals__student=student).order_by('-submitted_at')[:5], 'feedback_items':Feedback.objects.filter(progress__project__proposals__student=student).select_related('progress','supervisor__user').order_by('-created_at')[:5]})
    if role == User.Roles.SUPERVISOR:
        supervisor = get_object_or_404(Supervisor, user=request.user)
        return render(request, 'core/supervisor_dashboard.html', {'supervisor':supervisor,'pending_proposals':Proposal.objects.filter(status='pending').select_related('project','student__user'),'allocations':supervisor.allocations.filter(status='active').select_related('project'),'progress_items':Progress.objects.filter(project__allocations__supervisor=supervisor, project__allocations__status='active').select_related('project','submitted_by').order_by('-submitted_at')[:8]})
    raise PermissionDenied

@role_required('student')
def student_profile(request):
    student = get_object_or_404(Student, user=request.user)
    form = StudentProfileForm(request.POST or None, instance=student, user=request.user)
    if request.method == 'POST' and form.is_valid(): form.save(); messages.success(request,'Profile updated successfully.'); return redirect('student_profile')
    return render(request,'core/student_profile.html',{'form':form,'heading':'My profile','subtitle':'Keep your student details up to date.'})

@role_required('student')
def submit_proposal(request):
    if not Config.current().submission_open:
        messages.error(request,'The project submission period is currently closed.'); return redirect('dashboard')
    form = ProposalForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        project = form.save()
        Proposal.objects.create(project=project, student=get_object_or_404(Student,user=request.user))
        notify(request.user, f'Your proposal “{project.title}” was submitted successfully.')
        for supervisor_user in User.objects.filter(role=User.Roles.SUPERVISOR, is_active=True): notify(supervisor_user, f'New project proposal submitted: {project.title}.')
        messages.success(request,'Proposal submitted successfully.'); return redirect('dashboard')
    return render(request,'core/proposal_form.html',{'form':form,'heading':'Submit project proposal','subtitle':'Complete all fields to send your project for review.'})

@role_required('supervisor')
def review_proposal(request, pk):
    proposal = get_object_or_404(Proposal.objects.select_related('project','student__user'),pk=pk)
    if request.method == 'POST':
        action = request.POST.get('action'); comment = request.POST.get('comment','').strip()
        if action not in ('accept','reject'):
            messages.error(request,'Choose accept or reject.')
        elif action == 'reject' and not comment:
            messages.error(request,'A comment is compulsory when rejecting a proposal.')
        elif proposal.status != Proposal.Status.PENDING:
            messages.error(request,'This proposal has already been reviewed.')
        else:
            supervisor = get_object_or_404(Supervisor,user=request.user)
            proposal.status = Proposal.Status.ACCEPTED if action == 'accept' else Proposal.Status.REJECTED
            proposal.reviewed_by = supervisor; proposal.review_comments = comment
            proposal.save(); proposal.project.status = Project.Status.APPROVED if action == 'accept' else Project.Status.REJECTED; proposal.project.save()
            notify(proposal.student.user, f'Your proposal “{proposal.project.title}” was {proposal.status}. {comment}')
            messages.success(request,'Proposal review saved.'); return redirect('dashboard')
    return render(request,'core/review_proposal.html',{'proposal':proposal})

@role_required('supervisor')
def progress_detail(request, pk):
    supervisor = get_object_or_404(Supervisor,user=request.user)
    progress = get_object_or_404(Progress.objects.select_related('project','submitted_by'),pk=pk,project__allocations__supervisor=supervisor,project__allocations__status='active')
    if request.method == 'POST':
        comments = request.POST.get('comments','').strip()
        if not comments: messages.error(request,'Feedback comments are required.')
        else:
            Feedback.objects.create(progress=progress,supervisor=supervisor,comments=comments)
            notify(progress.submitted_by, f'Your supervisor provided feedback on {progress.project.title}.')
            messages.success(request,'Feedback submitted.'); return redirect('progress_detail',pk=pk)
    return render(request,'core/progress_detail.html',{'progress':progress})

@role_required('student')
def submit_progress(request):
    student = get_object_or_404(Student,user=request.user)
    allocation = Allocation.objects.filter(project__proposals__student=student,status='active').select_related('project').first()
    if not allocation:
        messages.error(request,'You can submit progress only after a supervisor has been allocated.'); return redirect('dashboard')
    form = ProgressForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        progress = form.save(commit=False); progress.project=allocation.project; progress.submitted_by=request.user; progress.save()
        notify(allocation.supervisor.user, f'New progress update submitted for {allocation.project.title}.')
        messages.success(request,'Progress update submitted.'); return redirect('dashboard')
    return render(request,'core/progress_form.html',{'form':form,'project':allocation.project,'heading':'Submit progress update','subtitle':'Share completed work and what remains to be done.'})

@login_required
def notifications(request):
    items = request.user.notifications.all()
    if request.method == 'POST':
        items.filter(is_read=False).update(is_read=True); messages.success(request,'All notifications marked as read.'); return redirect('notifications')
    return render(request,'core/notifications.html',{'items':items})

@role_required('admin')
def toggle_submission(request):
    if request.method == 'POST':
        cfg=Config.current(); cfg.submission_open=not cfg.submission_open; cfg.save()
        messages.success(request, 'Submission period opened.' if cfg.submission_open else 'Submission period closed.')
    return redirect('dashboard')

@role_required('admin')
def supervisor_list(request): return render(request,'core/supervisor_list.html',{'supervisors':Supervisor.objects.select_related('user').all()})

@role_required('admin')
def supervisor_create(request):
    form=SupervisorForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; user=User.objects.create_user(username=d['username'],email=d['email'],password=d['password'],role='supervisor',full_name=d['full_name'])
        Supervisor.objects.create(user=user,department=d['department'],expertise=d['expertise'],max_capacity=d['max_capacity'])
        messages.success(request,'Supervisor created.'); return redirect('supervisor_list')
    return render(request,'core/supervisor_form.html',{'form':form,'heading':'Add supervisor','subtitle':'Enter supervisor account details, expertise and maximum workload.'})

@role_required('admin')
def supervisor_edit(request, pk):
    supervisor=get_object_or_404(Supervisor.objects.select_related('user'),pk=pk)
    form=SupervisorForm(request.POST or None,instance=supervisor)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; u=supervisor.user; u.full_name=d['full_name']; u.username=d['username']; u.email=d['email'];
        if d.get('password'): u.set_password(d['password'])
        u.save(); supervisor.department=d['department']; supervisor.expertise=d['expertise']; supervisor.max_capacity=d['max_capacity']; supervisor.save()
        messages.success(request,'Supervisor updated.'); return redirect('supervisor_list')
    return render(request,'core/supervisor_form.html',{'form':form,'heading':'Edit supervisor','subtitle':'Update profile details and capacity.'})

@role_required('admin')
def allocation_page(request):
    proposals=Proposal.objects.filter(status='accepted').exclude(project__allocations__status='active').select_related('project','student__user')
    if request.method=='POST':
        proposal=get_object_or_404(Proposal,pk=request.POST.get('proposal_id'),status='accepted')
        supervisor=get_object_or_404(Supervisor,pk=request.POST.get('supervisor_id'))
        try:
            with transaction.atomic():
                locked=Supervisor.objects.select_for_update().get(pk=supervisor.pk)
                if locked.allocations.filter(status='active').count() >= locked.max_capacity: raise ValueError('This supervisor has reached maximum capacity.')
                if Allocation.objects.filter(project=proposal.project,status='active').exists(): raise ValueError('This project already has an active allocation.')
                Allocation.objects.create(project=proposal.project,supervisor=locked,allocated_by=request.user)
                proposal.project.status=Project.Status.IN_PROGRESS; proposal.project.save()
                notify(proposal.student.user,f'Supervisor {locked.user.full_name} has been assigned to {proposal.project.title}.')
                notify(locked.user,f'You have been assigned project {proposal.project.title}.')
            messages.success(request,'Supervisor allocated successfully.')
            return redirect('allocation_page')
        except (ValueError, IntegrityError) as exc: messages.error(request,str(exc) or 'Allocation could not be completed.')
    return render(request,'core/allocations.html',{'proposals':proposals,'supervisors':Supervisor.objects.select_related('user').all(),'allocations':Allocation.objects.filter(status='active').select_related('project','supervisor__user')})

@role_required('admin')
def allocation_report(request):
    allocations=Allocation.objects.filter(status='active').select_related('project','supervisor__user','allocated_by').order_by('supervisor__user__full_name')
    if request.GET.get('format')=='csv':
        response=HttpResponse(content_type='text/csv'); response['Content-Disposition']='attachment; filename="allocation-report.csv"'
        writer=csv.writer(response); writer.writerow(['Project','Student','Supervisor','Department','Allocated At','Status'])
        for a in allocations:
            proposal=a.project.proposals.select_related('student__user').first()
            writer.writerow([a.project.title, proposal.student.user.full_name if proposal else '', a.supervisor.user.full_name, a.supervisor.department, a.allocated_at.strftime('%Y-%m-%d %H:%M'), a.status])
        return response
    return render(request,'core/report.html',{'allocations':allocations})

```

## `manage.py`

```python
#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)

```

## `requirements.txt`

```text
Django>=5.0,<6.0

```

## `static/css/app.css`

```css
:root{--ink:#17213c;--muted:#77819a;--primary:#5546d7;--line:#e9ecf4;--surface:#fff;--bg:#f5f6fb}*{box-sizing:border-box}body{font-family:Inter,system-ui,sans-serif;background:var(--bg);color:var(--ink);font-size:14px}.app-shell{min-height:100vh}.sidebar{width:258px;position:fixed;inset:0 auto 0 0;background:linear-gradient(160deg,#211b52 0%,#30236d 52%,#4636a0 100%);color:#fff;padding:28px 19px;flex-direction:column;z-index:10}.brand{display:flex;align-items:center;gap:12px;color:#fff;text-decoration:none;font-size:19px;font-weight:800;letter-spacing:-.5px;margin:0 5px 48px}.brand-mark{height:42px;width:42px;border-radius:13px;background:#ffffff20;display:grid;place-items:center;font-size:21px}.brand-light{color:#bcb5ff}.brand small{display:block;font-size:8px;letter-spacing:1.6px;color:#b5afd9;font-weight:600;margin-top:3px}.nav-label,.eyebrow{font-size:9px;font-weight:800;letter-spacing:1.5px;color:#9b91cf}.nav-label{padding:0 12px 12px}.side-nav{display:flex;flex-direction:column;gap:6px}.side-nav a{display:flex;align-items:center;gap:13px;color:#c8c3e4;text-decoration:none;padding:12px 13px;border-radius:10px;font-weight:600;font-size:13px;transition:.2s}.side-nav a i{font-size:17px;width:19px}.side-nav a:hover,.side-nav a.active{background:#ffffff1b;color:#fff}.side-nav a.active{box-shadow:inset 3px 0 #a99fff}.nav-count{margin-left:auto;background:#ffbd68;color:#35245e;border-radius:20px;padding:2px 7px;font-size:10px}.sidebar-bottom{margin-top:auto}.user-mini{display:flex;align-items:center;gap:11px;padding:14px 8px;border-top:1px solid #ffffff20}.avatar,.top-avatar,.large-avatar{display:grid;place-items:center;background:#e9e6ff;color:#5546d7;font-weight:800;border-radius:50%}.avatar{width:37px;height:37px}.user-mini-text strong,.user-mini-text small{display:block}.user-mini-text strong{font-size:12px}.user-mini-text small{color:#bcb5dc;font-size:10px;margin-top:3px}.logout-link{border:0;background:transparent;color:#c9c3e5;padding:10px 9px;font-weight:600;font-size:12px}.logout-link i{margin-right:9px}.main-content{margin-left:258px;padding:34px 42px 60px;max-width:1700px}.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:32px}.topbar .eyebrow{color:#8a8fa7}.topbar h1{font-size:25px;font-weight:800;letter-spacing:-.8px;margin:6px 0 0}.topbar-user{display:flex;align-items:center;gap:10px}.top-avatar{width:36px;height:36px}.topbar-user strong,.topbar-user small{display:block}.topbar-user strong{font-size:12px}.topbar-user small{font-size:10px;color:var(--muted);margin-top:3px}.welcome-row{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:22px}.welcome-row h2{font-size:18px;font-weight:800;letter-spacing:-.4px;margin:0 0 5px}.welcome-row p,.panel-heading p{color:var(--muted);margin:0;font-size:12px}.btn{border-radius:9px;font-weight:600;font-size:12px;padding:10px 15px}.btn-primary{background:var(--primary);border-color:var(--primary);box-shadow:0 5px 12px #5546d725}.btn-primary:hover{background:#4435c2;border-color:#4435c2}.stats-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px;margin:22px 0}.stat-card,.panel{background:#fff;border:1px solid #edf0f6;border-radius:15px;box-shadow:0 5px 22px #25345c08}.stat-card{padding:18px 19px;min-height:140px;position:relative}.stat-icon{width:35px;height:35px;border-radius:10px;display:grid;place-items:center;font-size:17px;margin-bottom:13px}.purple{background:#f0edff;color:#6b56db}.blue{background:#e9f3ff;color:#3984d7}.indigo{background:#eeeefe;color:#6255c9}.amber{background:#fff4df;color:#d99325}.green{background:#e7f8ef;color:#27a56b}.red{background:#fff0f0;color:#db5b61}.teal{background:#e5f8f7;color:#269d9a}.stat-card>span{display:block;color:#7d879d;font-size:11px;font-weight:600}.stat-card>strong{display:block;font-size:25px;line-height:1.25;margin-top:3px;font-weight:800;letter-spacing:-1px}.stat-card>small{display:block;color:#a0a8b9;font-size:10px;margin-top:4px}.stat-word{font-size:20px!important}.panel{padding:22px;margin-bottom:18px}.panel-heading{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}.panel-heading h3{font-size:14px;font-weight:800;margin:0 0 5px}.panel-heading p{font-size:11px}.text-link{color:var(--primary);font-size:11px;font-weight:700;text-decoration:none}.app-table{font-size:12px;margin:0}.app-table thead th{font-size:9px;letter-spacing:.8px;text-transform:uppercase;color:#9aa2b3;font-weight:800;border-bottom:1px solid var(--line);padding:12px 10px}.app-table td{padding:14px 10px;vertical-align:middle;border-color:#f0f2f7;color:#59637a}.status-badge,.status-pill{display:inline-block;border-radius:30px;padding:5px 10px;font-size:10px;font-weight:700}.status-badge.pending{background:#fff4dc;color:#b77b18}.status-badge.accepted{background:#e6f7ee;color:#218b5a}.status-badge.rejected{background:#ffeded;color:#c84d55}.status-badge.in_progress{background:#eaf1ff;color:#466fc1}.status-badge.submitted{background:#eef0f7;color:#65718a}.empty-state{text-align:center;color:#9aa2b3;padding:28px 10px;font-size:12px}.period-banner{display:flex;align-items:center;gap:14px;padding:15px 18px;border-radius:12px;margin-bottom:18px}.period-banner>i{font-size:20px}.period-banner strong,.period-banner small{display:block}.period-banner strong{font-size:12px}.period-banner small{font-size:10px;margin-top:3px;opacity:.75}.period-banner .status-pill{margin-left:auto}.period-open{background:#eaf8f0;color:#258557}.period-closed{background:#fff1f0;color:#bd5151}.content-grid{display:grid;grid-template-columns:1.3fr .9fr;gap:18px}.proposal-item{display:flex;align-items:center;gap:13px;padding:14px 0;border-top:1px solid #f0f2f7}.proposal-symbol{width:36px;height:36px;border-radius:10px;background:#f0efff;color:#6655cf;display:grid;place-items:center;font-size:16px}.proposal-info{flex:1;min-width:0}.proposal-info strong,.proposal-info small{display:block}.proposal-info strong{font-size:12px}.proposal-info small{color:#9aa2b3;font-size:10px;margin-top:4px}.review-comment{font-size:11px;color:#68738b;margin:8px 0 0}.supervisor-profile{text-align:center;padding:8px 5px 16px}.large-avatar{width:55px;height:55px;margin:0 auto 12px;font-size:20px}.supervisor-profile strong,.supervisor-profile span,.supervisor-profile small{display:block}.supervisor-profile strong{font-size:14px}.supervisor-profile span{color:#7e879b;font-size:11px;margin-top:4px}.supervisor-profile small{color:#9ba3b2;font-size:10px;margin:8px auto;max-width:230px}.assigned-project{background:#f6f5ff;color:#6352c7;padding:10px;border-radius:9px;font-size:11px;margin-top:16px}.progress-row{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:13px 0;border-top:1px solid #f0f2f7}.progress-row strong,.progress-row small{display:block}.progress-row strong{font-size:12px}.progress-row small{font-size:10px;color:#929bad;margin-top:4px}.progress-row>span{font-size:10px;color:#929bad;white-space:nowrap}.capacity-chip{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:12px;padding:11px 16px;color:var(--primary)}.capacity-chip i{font-size:20px}.capacity-chip b,.capacity-chip small{display:block}.capacity-chip b{font-size:13px;color:var(--ink)}.capacity-chip small{font-size:9px;color:var(--muted)}.form-panel{max-width:780px}.form-control,.form-select{border:1px solid #e2e6ef;border-radius:9px;padding:11px 12px;font-size:12px;color:var(--ink)}.form-control:focus,.form-select:focus{border-color:#9b91ee;box-shadow:0 0 0 3px #6354d51a}.form-label{font-size:11px;font-weight:700;color:#505b72}.field-error{color:#d04f58;font-size:10px;margin-top:5px}.form-text{font-size:10px;color:#9aa2b3}.detail-panel{max-width:900px}.detail-panel h2{font-size:22px;font-weight:800}.muted{color:var(--muted);font-size:11px}.detail-block{border-top:1px solid var(--line);padding:17px 0}.detail-block h4{font-size:12px;font-weight:800}.detail-block p{font-size:12px;color:#66718a;line-height:1.7;margin:7px 0 0}.review-form{background:#f8f9fc;padding:18px;border-radius:12px}.feedback-box{padding:12px;background:#f6f7fb;border-radius:9px;font-size:12px;margin:8px 0}.feedback-box small{display:block;color:#9aa2b3;margin-top:6px}.notification-row{display:flex;align-items:center;gap:13px;padding:15px 5px;border-top:1px solid #f0f2f7}.notification-row>div:nth-child(2){flex:1}.notification-row strong,.notification-row small{display:block}.notification-row strong{font-size:11px;font-weight:600}.notification-row small{font-size:10px;color:#9aa2b3;margin-top:4px}.notification-row.unread{background:#faf9ff}.notification-icon{width:34px;height:34px;border-radius:50%;background:#f0efff;color:#6655cf;display:grid;place-items:center}.unread-dot{height:7px;width:7px;background:#6554d5;border-radius:50%}.report-heading{display:none}.report-total{text-align:right;color:#69748b;font-size:11px;padding-top:15px}.app-alert{border:0;border-radius:10px;font-size:12px}.login-layout{min-height:100vh;display:grid;grid-template-columns:1.05fr .95fr;background:#fff}.login-hero{background:linear-gradient(145deg,#211b52,#3c2c91 65%,#5546d7);color:#fff;padding:50px 9%;position:relative;overflow:hidden}.login-hero:after{content:'';position:absolute;width:480px;height:480px;border:1px solid #ffffff16;border-radius:50%;right:-210px;bottom:-230px;box-shadow:0 0 0 55px #ffffff08,0 0 0 110px #ffffff05}.hero-inner{height:100%;display:flex;flex-direction:column;position:relative;z-index:1}.hero-brand{font-weight:800;font-size:19px}.hero-brand i{margin-right:9px;color:#b7afff}.hero-copy{margin:auto 0;max-width:480px}.hero-kicker{font-size:9px;letter-spacing:1.7px;color:#b8b0ff;font-weight:800}.hero-copy h1{font-size:clamp(38px,5vw,61px);line-height:1.08;letter-spacing:-2.7px;font-weight:800;margin:20px 0}.hero-copy h1 em{font-style:normal;color:#bcb4ff}.hero-copy p{font-size:13px;color:#d0cbed;line-height:1.8;max-width:390px}.hero-features{margin-top:30px;display:grid;gap:15px;color:#eeeafd;font-size:12px}.hero-features i{color:#a9ffce;margin-right:9px}.hero-foot{font-size:8px;letter-spacing:1.4px;color:#a59bcf}.login-panel{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:40px 8%;position:relative}.login-card{width:100%;max-width:390px}.login-icon{width:48px;height:48px;background:#f0eeff;color:#5b4bd2;border-radius:14px;display:grid;place-items:center;font-size:21px;margin-bottom:25px}.login-card .eyebrow{color:#8275df}.login-card h2{font-size:25px;font-weight:800;letter-spacing:-.8px;margin:9px 0}.login-card .muted{font-size:12px;margin-bottom:30px}.input-icon{position:relative}.input-icon>i{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:#a1a8b8;z-index:2}.input-icon input{width:100%;padding:13px 12px 13px 40px;border:1px solid #e3e6ef;border-radius:9px;font-size:12px}.input-icon input:focus{outline:0;border-color:#8b80e7;box-shadow:0 0 0 3px #6354d51a}.login-note{font-size:10px;color:#929bad;text-align:center;margin-top:25px}.login-note i{margin-right:5px}.login-copyright{position:absolute;bottom:24px;color:#a5acbb;font-size:9px}.mobile-top{height:60px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 17px;box-shadow:0 2px 12px #1c27500b}.mobile-bell{color:#5546d7;position:relative}.mobile-bell b{font-size:9px;background:#f6a84a;color:#fff;border-radius:20px;padding:2px 5px}.mobile-drawer{background:#2b2267;color:#fff}.mobile-drawer a{display:block;padding:13px;color:#fff;text-decoration:none}.mobile-drawer .offcanvas-header{border-bottom:1px solid #ffffff22}.mobile-drawer .logout-link{color:#fff}@media(max-width:1200px){.stats-grid{grid-template-columns:repeat(3,1fr)}.main-content{padding:28px}}@media(max-width:991px){.main-content{margin:0;padding:25px 18px 45px}.topbar{margin-bottom:25px}.content-grid{grid-template-columns:1fr}.stats-grid{grid-template-columns:repeat(2,1fr)}.login-layout{grid-template-columns:1fr}.login-hero{min-height:380px;padding:30px 8%}.hero-copy{margin:60px 0 35px}.hero-copy h1{font-size:42px}.login-panel{min-height:560px}.login-copyright{position:static;margin-top:35px}}@media(max-width:560px){.topbar-user{display:none}.topbar h1{font-size:21px}.welcome-row{align-items:flex-start;flex-direction:column}.stats-grid{gap:10px}.stat-card{padding:14px;min-height:128px}.stat-card>strong{font-size:22px}.panel{padding:16px}.period-banner{align-items:flex-start}.period-banner .status-pill{font-size:9px}.proposal-item{flex-wrap:wrap}.proposal-item .status-badge{margin-left:49px}.login-hero{min-height:420px}.hero-copy h1{font-size:39px}.login-panel{padding:35px 23px}.capacity-chip{align-self:flex-start}}@media print{body{background:#fff}.sidebar,.topbar,.mobile-top,.no-print,.app-alert{display:none!important}.main-content{margin:0;padding:0;max-width:none}.panel{box-shadow:none;border:0;padding:0}.report-heading{display:block;text-align:center;margin-bottom:24px}.report-heading h2{font-size:18px}.report-heading p{font-size:10px}.app-table{font-size:10px}}
.form-panel input:not([type=checkbox]),.form-panel textarea,.form-panel select{width:100%;border:1px solid #e2e6ef;border-radius:9px;padding:11px 12px;font-size:12px;color:var(--ink);background:#fff}.form-panel input:focus,.form-panel textarea:focus,.form-panel select:focus{outline:0;border-color:#9b91ee;box-shadow:0 0 0 3px #6354d51a}

```

## `templates/base.html`

```html
{% load static %}<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{% block title %}Project Allocation{% endblock %}</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="{% static 'css/app.css' %}" rel="stylesheet"></head><body>
{% if user.is_authenticated %}<div class="app-shell"><aside class="sidebar d-none d-lg-flex"><a class="brand" href="{% url 'dashboard' %}"><span class="brand-mark"><i class="bi bi-mortarboard-fill"></i></span><span>Project<span class="brand-light">Hub</span><small>ALLOCATION PORTAL</small></span></a><div class="nav-label">WORKSPACE</div><nav class="side-nav">
<a class="{% if request.resolver_match.url_name == 'dashboard' %}active{% endif %}" href="{% url 'dashboard' %}"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
{% if user.role == 'student' %}<a href="{% url 'student_profile' %}"><i class="bi bi-person-vcard"></i> My Profile</a><a href="{% url 'submit_proposal' %}"><i class="bi bi-file-earmark-plus"></i> Submit Proposal</a><a href="{% url 'submit_progress' %}"><i class="bi bi-graph-up-arrow"></i> Project Progress</a>{% endif %}
{% if user.role == 'supervisor' %}<a href="{% url 'dashboard' %}#proposals"><i class="bi bi-inbox"></i> Proposal Reviews</a>{% endif %}
{% if user.role == 'admin' %}<a href="{% url 'supervisor_list' %}"><i class="bi bi-people"></i> Supervisors</a><a href="{% url 'allocation_page' %}"><i class="bi bi-diagram-3"></i> Allocations</a><a href="{% url 'allocation_report' %}"><i class="bi bi-file-earmark-bar-graph"></i> Reports</a><a href="/admin/"><i class="bi bi-gear"></i> Account Admin</a>{% endif %}
<a href="{% url 'notifications' %}"><i class="bi bi-bell"></i> Notifications {% if unread_notifications %}<span class="nav-count">{{ unread_notifications }}</span>{% endif %}</a></nav><div class="sidebar-bottom"><div class="user-mini"><div class="avatar">{{ user.full_name|default:user.username|first|upper }}</div><div class="user-mini-text"><strong>{{ user.full_name|default:user.username }}</strong><small>{{ user.get_role_display }}</small></div></div><form method="post" action="{% url 'logout' %}">{% csrf_token %}<button class="logout-link"><i class="bi bi-box-arrow-left"></i> Sign out</button></form></div></aside>
<div class="mobile-top d-lg-none"><button class="btn btn-light" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu"><i class="bi bi-list fs-4"></i></button><span class="fw-bold">ProjectHub</span><a href="{% url 'notifications' %}" class="mobile-bell"><i class="bi bi-bell"></i>{% if unread_notifications %}<b>{{ unread_notifications }}</b>{% endif %}</a></div><div class="offcanvas offcanvas-start mobile-drawer" tabindex="-1" id="mobileMenu"><div class="offcanvas-header"><h5>ProjectHub</h5><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><a href="{% url 'dashboard' %}">Dashboard</a>{% if user.role == 'student' %}<a href="{% url 'student_profile' %}">My Profile</a><a href="{% url 'submit_proposal' %}">Submit Proposal</a><a href="{% url 'submit_progress' %}">Project Progress</a>{% endif %}{% if user.role == 'admin' %}<a href="{% url 'supervisor_list' %}">Supervisors</a><a href="{% url 'allocation_page' %}">Allocations</a><a href="{% url 'allocation_report' %}">Reports</a>{% endif %}<a href="{% url 'notifications' %}">Notifications</a><form method="post" action="{% url 'logout' %}">{% csrf_token %}<button class="logout-link">Sign out</button></form></div></div>
<main class="main-content"><header class="topbar"><div><span class="eyebrow">STUDENT PROJECT MANAGEMENT</span><h1>{% block page_heading %}Dashboard{% endblock %}</h1></div><div class="topbar-user"><span class="top-avatar">{{ user.full_name|default:user.username|first|upper }}</span><div><strong>{{ user.full_name|default:user.username }}</strong><small>{{ user.get_role_display }}</small></div></div></header>
{% for message in messages %}<div class="alert alert-{{ message.tags|default:'info' }} alert-dismissible fade show app-alert"><i class="bi {% if message.tags == 'success' %}bi-check-circle-fill{% else %}bi-exclamation-circle-fill{% endif %}"></i> {{ message }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>{% endfor %}{% block content %}{% endblock %}</main></div>
{% else %}{% block public_content %}{% endblock %}{% endif %}<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>

```

## `templates/core/admin_dashboard.html`

```html
{% extends 'base.html' %}{% block page_heading %}Administrator dashboard{% endblock %}{% block content %}<div class="welcome-row"><div><h2>System overview</h2><p>Monitor proposals, supervisors and project allocations.</p></div><form method="post" action="{% url 'toggle_submission' %}">{% csrf_token %}<button class="btn {% if config.submission_open %}btn-outline-danger{% else %}btn-success{% endif %}"><i class="bi bi-toggle-{% if config.submission_open %}on{% else %}off{% endif %} me-2"></i>{% if config.submission_open %}Close submissions{% else %}Open submissions{% endif %}</button></form></div><div class="period-banner {% if config.submission_open %}period-open{% else %}period-closed{% endif %}"><i class="bi bi-calendar2-check"></i><div><strong>Proposal submission period is {{ config.submission_open|yesno:'OPEN,CLOSED' }}</strong><small>{% if config.submission_open %}Students can submit new project proposals.{% else %}New proposal submissions are currently disabled.{% endif %}</small></div><span class="status-pill">{{ config.submission_open|yesno:'Open,Closed' }}</span></div><div class="stats-grid"><div class="stat-card"><div class="stat-icon purple"><i class="bi bi-mortarboard"></i></div><span>Students</span><strong>{{ students_count }}</strong><small>Registered accounts</small></div><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-person-workspace"></i></div><span>Supervisors</span><strong>{{ supervisors_count }}</strong><small>Available faculty</small></div><div class="stat-card"><div class="stat-icon indigo"><i class="bi bi-folder2-open"></i></div><span>Total proposals</span><strong>{{ total_proposals }}</strong><small>All submissions</small></div><div class="stat-card"><div class="stat-icon amber"><i class="bi bi-hourglass-split"></i></div><span>Pending</span><strong>{{ pending }}</strong><small>Awaiting review</small></div><div class="stat-card"><div class="stat-icon green"><i class="bi bi-check2-circle"></i></div><span>Approved</span><strong>{{ approved }}</strong><small>Accepted proposals</small></div><div class="stat-card"><div class="stat-icon red"><i class="bi bi-x-circle"></i></div><span>Rejected</span><strong>{{ rejected }}</strong><small>Rejected proposals</small></div><div class="stat-card"><div class="stat-icon teal"><i class="bi bi-diagram-3"></i></div><span>Active allocations</span><strong>{{ allocations_count }}</strong><small>Assigned projects</small></div></div><section class="panel"><div class="panel-heading"><div><h3>Recent proposals</h3><p>Latest student project submissions</p></div><a class="text-link" href="{% url 'allocation_page' %}">Manage allocations <i class="bi bi-arrow-up-right"></i></a></div><div class="table-responsive"><table class="table app-table"><thead><tr><th>Project</th><th>Student</th><th>Submitted</th><th>Status</th></tr></thead><tbody>{% for p in recent_proposals %}<tr><td class="fw-semibold">{{ p.project.title }}</td><td>{{ p.student.user.full_name }}</td><td>{{ p.submitted_at|date:'d M Y' }}</td><td><span class="status-badge {{ p.status }}">{{ p.get_status_display }}</span></td></tr>{% empty %}<tr><td colspan="4" class="empty-state">No proposals submitted yet.</td></tr>{% endfor %}</tbody></table></div></section>{% endblock %}

```

## `templates/core/allocations.html`

```html
{% extends 'base.html' %}{% block page_heading %}Supervisor allocations{% endblock %}{% block content %}<div class="welcome-row"><div><h2>Allocate a supervisor</h2><p>Only accepted proposals without an active allocation are listed.</p></div></div><section class="panel"><div class="table-responsive"><table class="table app-table"><thead><tr><th>Project / Student</th><th>Proposal</th><th>Supervisor</th><th>Action</th></tr></thead><tbody>{% for p in proposals %}<tr><td><strong>{{ p.project.title }}</strong><small class="d-block muted">{{ p.student.user.full_name }}</small></td><td><span class="status-badge accepted">Accepted</span></td><td><form method="post" class="d-flex gap-2">{% csrf_token %}<input type="hidden" name="proposal_id" value="{{ p.pk }}"><select class="form-select form-select-sm" name="supervisor_id" required><option value="">Choose supervisor</option>{% for s in supervisors %}<option value="{{ s.pk }}" {% if s.available_capacity == 0 %}disabled{% endif %}>{{ s.user.full_name }} · {{ s.workload }}/{{ s.max_capacity }} slots</option>{% endfor %}</select><button class="btn btn-sm btn-primary">Allocate</button></form></td><td></td></tr>{% empty %}<tr><td colspan="4" class="empty-state">No accepted projects need allocation.</td></tr>{% endfor %}</tbody></table></div></section><section class="panel mt-4"><div class="panel-heading"><div><h3>Active allocations</h3><p>Current project-supervisor assignments</p></div><a class="text-link" href="{% url 'allocation_report' %}">View report</a></div><div class="table-responsive"><table class="table app-table"><thead><tr><th>Project</th><th>Supervisor</th><th>Department</th><th>Allocated</th></tr></thead><tbody>{% for a in allocations %}<tr><td>{{ a.project.title }}</td><td>{{ a.supervisor.user.full_name }}</td><td>{{ a.supervisor.department }}</td><td>{{ a.allocated_at|date:'d M Y' }}</td></tr>{% empty %}<tr><td colspan="4" class="empty-state">No active allocations yet.</td></tr>{% endfor %}</tbody></table></div></section>{% endblock %}

```

## `templates/core/form_page.html`

```html
{% extends 'base.html' %}{% block content %}<section class="panel form-panel"><div class="panel-heading"><div><h3>{{ heading }}</h3><p>{{ subtitle }}</p></div></div><form method="post" novalidate>{% csrf_token %}{% for field in form %}<div class="mb-3"><label class="form-label" for="{{ field.id_for_label }}">{{ field.label }}{% if field.field.required %} <span class="text-danger">*</span>{% endif %}</label>{{ field }}{% if field.help_text %}<div class="form-text">{{ field.help_text }}</div>{% endif %}{% for error in field.errors %}<div class="field-error">{{ error }}</div>{% endfor %}</div>{% endfor %}{% if form.non_field_errors %}<div class="field-error">{{ form.non_field_errors }}</div>{% endif %}<div class="d-flex gap-2 mt-4"><button class="btn btn-primary">Save changes</button><a href="{% url 'dashboard' %}" class="btn btn-light">Cancel</a></div></form></section>{% endblock %}

```

## `templates/core/notifications.html`

```html
{% extends 'base.html' %}{% block page_heading %}Notifications{% endblock %}{% block content %}<section class="panel"><div class="panel-heading"><div><h3>Your notifications</h3><p>Updates about proposals, allocation and project progress</p></div><form method="post">{% csrf_token %}<button class="btn btn-outline-primary btn-sm"><i class="bi bi-check2-all me-1"></i>Mark all as read</button></form></div>{% for item in items %}<div class="notification-row {% if not item.is_read %}unread{% endif %}"><div class="notification-icon"><i class="bi bi-bell"></i></div><div><strong>{{ item.message }}</strong><small>{{ item.created_at|date:'d M Y, h:i A' }}</small></div>{% if not item.is_read %}<span class="unread-dot"></span>{% endif %}</div>{% empty %}<div class="empty-state">You’re all caught up. No notifications yet.</div>{% endfor %}</section>{% endblock %}

```

## `templates/core/progress_detail.html`

```html
{% extends 'base.html' %}{% block page_heading %}Progress review{% endblock %}{% block content %}<section class="panel detail-panel"><h2>{{ progress.project.title }}</h2><p class="muted">Submitted by {{ progress.submitted_by.full_name }} · {{ progress.submitted_at|date:'d M Y, h:i A' }}</p><div class="detail-block"><h4>Completed tasks</h4><p>{{ progress.completed_tasks|linebreaksbr }}</p></div><div class="detail-block"><h4>Pending tasks</h4><p>{{ progress.pending_tasks|linebreaksbr }}</p></div><div class="detail-block"><h4>Progress description</h4><p>{{ progress.description|linebreaksbr }}</p></div><h3 class="mt-4">Previous feedback</h3>{% for f in progress.feedback_entries.all %}<div class="feedback-box">{{ f.comments }}<small>{{ f.created_at|date:'d M Y, h:i A' }}</small></div>{% empty %}<p class="muted">No feedback yet.</p>{% endfor %}<form method="post" class="mt-4">{% csrf_token %}<label class="form-label">Your feedback</label><textarea class="form-control" name="comments" rows="3" required></textarea><button class="btn btn-primary mt-3">Send feedback</button></form></section>{% endblock %}

```

## `templates/core/progress_form.html`

```html
{% extends 'core/form_page.html' %}{% block page_heading %}Project progress{% endblock %}{% block content %}<div class="mb-3 muted">Project: <strong>{{ project.title }}</strong></div>{{ block.super }}{% endblock %}{% block title %}Progress update{% endblock %}

```

## `templates/core/proposal_form.html`

```html
{% extends 'core/form_page.html' %}{% block page_heading %}Submit project proposal{% endblock %}{% block content %}{{ block.super }}{% endblock %}{% block title %}New proposal{% endblock %}

```

## `templates/core/report.html`

```html
{% extends 'base.html' %}{% block page_heading %}Allocation report{% endblock %}{% block content %}<div class="welcome-row no-print"><div><h2>Project allocation report</h2><p>Active supervisor assignments across the department.</p></div><div class="d-flex gap-2"><a class="btn btn-outline-primary" href="?format=csv"><i class="bi bi-download me-2"></i>Download CSV</a><button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer me-2"></i>Print report</button></div></div><section class="panel"><div class="report-heading"><h2>Student Project & Supervisor Allocation</h2><p>Generated {% now 'd M Y' %}</p></div><div class="table-responsive"><table class="table app-table"><thead><tr><th>Project</th><th>Student</th><th>Supervisor</th><th>Department</th><th>Allocation date</th></tr></thead><tbody>{% for a in allocations %}{% with p=a.project.proposals.first %}<tr><td>{{ a.project.title }}</td><td>{% if p %}{{ p.student.user.full_name }}{% else %}—{% endif %}</td><td>{{ a.supervisor.user.full_name }}</td><td>{{ a.supervisor.department }}</td><td>{{ a.allocated_at|date:'d M Y' }}</td></tr>{% endwith %}{% empty %}<tr><td colspan="5" class="empty-state">No active allocations to report.</td></tr>{% endfor %}</tbody></table></div><div class="report-total">Total active allocations: <strong>{{ allocations.count }}</strong></div></section>{% endblock %}

```

## `templates/core/review_proposal.html`

```html
{% extends 'base.html' %}{% block page_heading %}Review proposal{% endblock %}{% block content %}<section class="panel detail-panel"><span class="status-badge {{ proposal.status }}">{{ proposal.get_status_display }}</span><h2 class="mt-3">{{ proposal.project.title }}</h2><p class="muted">Submitted by {{ proposal.student.user.full_name }} · {{ proposal.submitted_at|date:'d M Y, h:i A' }}</p><div class="detail-block"><h4>Description</h4><p>{{ proposal.project.description }}</p></div><div class="detail-block"><h4>Objectives</h4><p>{{ proposal.project.objectives }}</p></div><div class="detail-block"><h4>Proposed technologies</h4><p>{{ proposal.project.technologies }}</p></div><form method="post" class="review-form">{% csrf_token %}<label class="form-label">Review comments {% if proposal.status == 'pending' %}<span class="text-danger">(required when rejecting)</span>{% endif %}</label><textarea class="form-control" name="comment" rows="4" placeholder="Provide feedback or suggestions...">{{ proposal.review_comments }}</textarea><div class="d-flex gap-2 mt-3"><button class="btn btn-success" name="action" value="accept"><i class="bi bi-check-lg me-1"></i>Accept proposal</button><button class="btn btn-danger" name="action" value="reject"><i class="bi bi-x-lg me-1"></i>Reject proposal</button><a class="btn btn-light" href="{% url 'dashboard' %}">Back</a></div></form></section>{% endblock %}

```

## `templates/core/student_dashboard.html`

```html
{% extends 'base.html' %}{% block page_heading %}Student dashboard{% endblock %}{% block content %}<div class="welcome-row"><div><h2>Hello, {{ user.full_name|default:user.username }} <span>👋</span></h2><p>Here’s the latest update on your project journey.</p></div><a class="btn btn-primary" href="{% url 'submit_proposal' %}"><i class="bi bi-plus-lg me-2"></i>New proposal</a></div><div class="stats-grid student-stats"><div class="stat-card"><div class="stat-icon purple"><i class="bi bi-file-earmark-text"></i></div><span>My proposals</span><strong>{{ proposals.count }}</strong><small>Submitted projects</small></div><div class="stat-card"><div class="stat-icon green"><i class="bi bi-person-check"></i></div><span>Supervisor</span><strong class="stat-word">{% if allocation %}Assigned{% else %}Pending{% endif %}</strong><small>Allocation status</small></div><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-activity"></i></div><span>Progress updates</span><strong>{{ progress.count }}</strong><small>Recent updates</small></div></div><div class="content-grid"><section class="panel"><div class="panel-heading"><div><h3>My proposals</h3><p>Track your submission and review status</p></div></div>{% for p in proposals %}<div class="proposal-item"><div class="proposal-symbol"><i class="bi bi-file-earmark-code"></i></div><div class="proposal-info"><strong>{{ p.project.title }}</strong><small>Submitted {{ p.submitted_at|date:'d M Y' }}</small>{% if p.review_comments %}<p class="review-comment"><i class="bi bi-chat-left-text"></i> {{ p.review_comments }}</p>{% endif %}</div><span class="status-badge {{ p.status }}">{{ p.get_status_display }}</span></div>{% empty %}<div class="empty-state">You haven’t submitted a proposal yet.</div>{% endfor %}</section><section class="panel"><div class="panel-heading"><div><h3>Supervisor details</h3><p>Your project guidance</p></div></div>{% if allocation %}<div class="supervisor-profile"><div class="large-avatar">{{ allocation.supervisor.user.full_name|first|upper }}</div><strong>{{ allocation.supervisor.user.full_name }}</strong><span>{{ allocation.supervisor.department }}</span><small>{{ allocation.supervisor.expertise }}</small><div class="assigned-project"><i class="bi bi-folder-check"></i> {{ allocation.project.title }}</div></div>{% else %}<div class="empty-state"><i class="bi bi-person-plus fs-2 d-block mb-2"></i>No supervisor allocated yet.</div>{% endif %}</section></div><section class="panel mt-4"><div class="panel-heading"><div><h3>Recent progress</h3><p>Your submitted project updates</p></div>{% if allocation %}<a href="{% url 'submit_progress' %}" class="text-link">Add update <i class="bi bi-arrow-right"></i></a>{% endif %}</div>{% for item in progress %}<div class="progress-row"><div><strong>{{ item.project.title }}</strong><small>{{ item.description }}</small></div><span>{{ item.submitted_at|date:'d M Y' }}</span></div>{% empty %}<div class="empty-state">No progress updates yet.</div>{% endfor %}</section><section class="panel mt-4"><div class="panel-heading"><div><h3>Supervisor feedback</h3><p>Comments on your submitted progress</p></div></div>{% for f in feedback_items %}<div class="feedback-box"><strong>{{ f.supervisor.user.full_name }}</strong><div>{{ f.comments }}</div><small>{{ f.created_at|date:'d M Y, h:i A' }}</small></div>{% empty %}<div class="empty-state">No supervisor feedback yet.</div>{% endfor %}</section>{% endblock %}

```

## `templates/core/student_profile.html`

```html
{% extends 'core/form_page.html' %}{% block page_heading %}My profile{% endblock %}{% block content %}{{ block.super }}{% endblock %}{% block title %}My profile{% endblock %}

```

## `templates/core/supervisor_dashboard.html`

```html
{% extends 'base.html' %}{% block page_heading %}Supervisor dashboard{% endblock %}{% block content %}<div class="welcome-row"><div><h2>Welcome, {{ user.full_name }}</h2><p>Review proposals and guide your assigned projects.</p></div><div class="capacity-chip"><i class="bi bi-people"></i><span><b>{{ supervisor.workload }} / {{ supervisor.max_capacity }}</b><small>Current workload</small></span></div></div><div class="stats-grid"><div class="stat-card"><div class="stat-icon amber"><i class="bi bi-inbox"></i></div><span>Pending proposals</span><strong>{{ pending_proposals.count }}</strong><small>Awaiting your review</small></div><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-folder2"></i></div><span>Assigned projects</span><strong>{{ allocations.count }}</strong><small>Active allocations</small></div><div class="stat-card"><div class="stat-icon green"><i class="bi bi-person-check"></i></div><span>Available capacity</span><strong>{{ supervisor.available_capacity }}</strong><small>Remaining slots</small></div></div><div class="content-grid"><section class="panel" id="proposals"><div class="panel-heading"><div><h3>Pending proposals</h3><p>Review and make a decision</p></div></div>{% for p in pending_proposals %}<div class="proposal-item"><div class="proposal-info"><strong>{{ p.project.title }}</strong><small>By {{ p.student.user.full_name }} · {{ p.submitted_at|date:'d M Y' }}</small></div><a class="btn btn-sm btn-outline-primary" href="{% url 'review_proposal' p.pk %}">Review <i class="bi bi-arrow-right"></i></a></div>{% empty %}<div class="empty-state">No proposals are waiting for review.</div>{% endfor %}</section><section class="panel"><div class="panel-heading"><div><h3>Assigned projects</h3><p>Your active supervision list</p></div></div>{% for a in allocations %}<div class="proposal-item"><div class="proposal-symbol"><i class="bi bi-kanban"></i></div><div class="proposal-info"><strong>{{ a.project.title }}</strong><small>Allocated {{ a.allocated_at|date:'d M Y' }}</small></div><span class="status-badge in_progress">Active</span></div>{% empty %}<div class="empty-state">No projects assigned yet.</div>{% endfor %}</section></div><section class="panel mt-4"><div class="panel-heading"><div><h3>Latest progress updates</h3><p>Submitted by your assigned students</p></div></div>{% for item in progress_items %}<div class="progress-row"><div><strong>{{ item.project.title }} · {{ item.submitted_by.full_name }}</strong><small>{{ item.description }}</small></div><a class="text-link" href="{% url 'progress_detail' item.pk %}">View & feedback</a></div>{% empty %}<div class="empty-state">No progress updates to review.</div>{% endfor %}</section>{% endblock %}

```

## `templates/core/supervisor_form.html`

```html
{% extends 'core/form_page.html' %}{% block page_heading %}{{ heading }}{% endblock %}{% block title %}{{ heading }}{% endblock %}

```

## `templates/core/supervisor_list.html`

```html
{% extends 'base.html' %}{% block page_heading %}Supervisor management{% endblock %}{% block content %}<div class="welcome-row"><div><h2>Supervisors</h2><p>Manage faculty profiles and supervision capacity.</p></div><a href="{% url 'supervisor_create' %}" class="btn btn-primary"><i class="bi bi-plus-lg me-2"></i>Add supervisor</a></div><section class="panel"><div class="table-responsive"><table class="table app-table"><thead><tr><th>Supervisor</th><th>Department</th><th>Expertise</th><th>Workload</th><th>Capacity</th><th></th></tr></thead><tbody>{% for s in supervisors %}<tr><td><strong>{{ s.user.full_name }}</strong><small class="d-block muted">{{ s.user.email }}</small></td><td>{{ s.department }}</td><td>{{ s.expertise }}</td><td>{{ s.workload }}</td><td>{{ s.max_capacity }}</td><td><a href="{% url 'supervisor_edit' s.pk %}" class="btn btn-sm btn-outline-primary">Edit</a></td></tr>{% empty %}<tr><td colspan="6" class="empty-state">No supervisors added.</td></tr>{% endfor %}</tbody></table></div></section>{% endblock %}

```

## `templates/registration/login.html`

```html
{% extends 'base.html' %}{% block title %}Sign in · ProjectHub{% endblock %}{% block public_content %}<div class="login-layout"><section class="login-hero"><div class="hero-inner"><div class="hero-brand"><i class="bi bi-mortarboard-fill"></i> ProjectHub</div><div class="hero-copy"><span class="hero-kicker">YOUR ACADEMIC JOURNEY, ORGANIZED</span><h1>Great projects<br>start with the<br><em>right guidance.</em></h1><p>A smarter space to submit ideas, connect with supervisors, and bring your university projects to life.</p><div class="hero-features"><div><i class="bi bi-check2-circle"></i> Simple proposal submission</div><div><i class="bi bi-check2-circle"></i> Transparent supervisor allocation</div><div><i class="bi bi-check2-circle"></i> Progress tracking and feedback</div></div></div><div class="hero-foot">STUDENT PROJECT & SUPERVISOR ALLOCATION SYSTEM</div></div></section><section class="login-panel"><div class="login-card"><div class="login-icon"><i class="bi bi-shield-lock"></i></div><span class="eyebrow">WELCOME BACK</span><h2>Sign in to your account</h2><p class="muted">Enter your credentials to continue to your workspace.</p>{% for message in messages %}<div class="alert alert-danger py-2">{{ message }}</div>{% endfor %}<form method="post" novalidate>{% csrf_token %}<div class="mb-3"><label class="form-label">Email or username</label><div class="input-icon"><i class="bi bi-person"></i>{{ form.username }}</div>{% for e in form.username.errors %}<small class="text-danger">{{ e }}</small>{% endfor %}</div><div class="mb-4"><label class="form-label">Password</label><div class="input-icon"><i class="bi bi-lock"></i>{{ form.password }}</div></div><button class="btn btn-primary w-100 btn-lg">Sign in <i class="bi bi-arrow-right ms-2"></i></button></form><div class="login-note"><i class="bi bi-info-circle"></i> Access is provided by your department administrator.</div></div><div class="login-copyright">© 2026 ProjectHub · Academic project workspace</div></section></div>{% endblock %}

```
